const express = require('express');
const { body } = require('express-validator');
const authController = require('../controllers/auth.controller');
const { validateRequest } = require('../middleware/validateRequest');
const { authRateLimiter } = require('../middleware/rateLimiter');
const { authenticate } = require('../middleware/authenticate');

const router = express.Router();

/**
 * Apply auth rate limiter to sensitive auth endpoints
 */
router.use(['/register', '/login', '/refresh'], authRateLimiter);

/**
 * @route POST /api/auth/register
 * @desc Register a new user
 * @access Public
 */
router.post(
  '/register',
  [
    body('email')
      .isEmail()
      .withMessage('Please provide a valid email')
      .normalizeEmail(),
    body('password')
      .isLength({ min: 8 })
      .withMessage('Password must be at least 8 characters long')
      .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/)
      .withMessage('Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character'),
    body('name')
      .not().isEmpty()
      .withMessage('Name is required')
      .trim()
      .escape(),
    validateRequest
  ],
  authController.register
);

/**
 * @route POST /api/auth/login
 * @desc Login user and return JWT token
 * @access Public
 */
router.post(
  '/login',
  [
    body('email')
      .isEmail()
      .withMessage('Please provide a valid email')
      .normalizeEmail(),
    body('password')
      .not().isEmpty()
      .withMessage('Password is required'),
    validateRequest
  ],
  authController.login
);

/**
 * @route GET /api/auth/me
 * @desc Get current user
 * @access Private
 */
router.get('/me', authenticate, authController.getMe);

/**
 * @route POST /api/auth/refresh
 * @desc Refresh JWT token
 * @access Public
 */
router.post(
  '/refresh',
  [
    body('refreshToken')
      .not().isEmpty()
      .withMessage('Refresh token is required'),
    validateRequest
  ],
  authController.refreshToken
);

/**
 * @route POST /api/auth/logout
 * @desc Logout user / clear cookie
 * @access Private
 */
router.post('/logout', authenticate, authController.logout);

/**
 * @route GET /api/auth/google
 * @desc Google OAuth login
 * @access Public
 */
router.get('/google', authController.googleAuth);

/**
 * @route GET /api/auth/google/callback
 * @desc Google OAuth callback
 * @access Public
 */
router.get('/google/callback', authController.googleCallback);

module.exports = router;
