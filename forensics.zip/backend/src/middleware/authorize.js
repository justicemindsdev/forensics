const { ApiError } = require('./errorHandler');

/**
 * Authorization middleware
 * Restricts access to routes based on user roles
 * @param {string|string[]} roles - Required role(s) to access the route
 */
const authorize = (roles) => {
  // Convert single role to array
  if (typeof roles === 'string') {
    roles = [roles];
  }

  return (req, res, next) => {
    try {
      // Check if user exists (should be attached by authenticate middleware)
      if (!req.user) {
        throw new ApiError(401, 'User not authenticated');
      }

      // Check if user has required role
      if (!roles.includes(req.user.role)) {
        throw new ApiError(403, 'You do not have permission to access this resource');
      }

      next();
    } catch (error) {
      next(error);
    }
  };
};

module.exports = {
  authorize
};
