const express = require('express');
const { param, query, body } = require('express-validator');
const transcriptController = require('../controllers/transcript.controller');
const { validateRequest } = require('../middleware/validateRequest');
const { authenticate } = require('../middleware/authenticate');

const router = express.Router();

// Apply authentication middleware to all routes
router.use(authenticate);

/**
 * @route GET /api/transcripts
 * @desc Get all transcripts for the current user
 * @access Private
 */
router.get('/', transcriptController.getTranscripts);

/**
 * @route GET /api/transcripts/:id
 * @desc Get a transcript by ID
 * @access Private
 */
router.get(
  '/:id',
  [
    param('id').isString().withMessage('Invalid transcript ID'),
    validateRequest
  ],
  transcriptController.getTranscriptById
);

/**
 * @route GET /api/transcripts/:id/insights
 * @desc Get insights for a transcript
 * @access Private
 */
router.get(
  '/:id/insights',
  [
    param('id').isString().withMessage('Invalid transcript ID'),
    validateRequest
  ],
  transcriptController.getTranscriptInsights
);

/**
 * @route GET /api/transcripts/:id/action-items
 * @desc Get action items for a transcript
 * @access Private
 */
router.get(
  '/:id/action-items',
  [
    param('id').isString().withMessage('Invalid transcript ID'),
    validateRequest
  ],
  transcriptController.getTranscriptActionItems
);

/**
 * @route GET /api/transcripts/:id/summary
 * @desc Get summary for a transcript
 * @access Private
 */
router.get(
  '/:id/summary',
  [
    param('id').isString().withMessage('Invalid transcript ID'),
    validateRequest
  ],
  transcriptController.getTranscriptSummary
);

/**
 * @route POST /api/transcripts/:id/share
 * @desc Share a transcript with other users
 * @access Private
 */
router.post(
  '/:id/share',
  [
    param('id').isString().withMessage('Invalid transcript ID'),
    body('emails').isArray().withMessage('Emails must be an array'),
    body('emails.*').isEmail().withMessage('Invalid email address'),
    validateRequest
  ],
  transcriptController.shareTranscript
);

/**
 * @route GET /api/transcripts/search
 * @desc Search transcripts
 * @access Private
 */
router.get(
  '/search',
  [
    query('q').isString().notEmpty().withMessage('Search query is required'),
    validateRequest
  ],
  transcriptController.searchTranscripts
);

module.exports = router;
