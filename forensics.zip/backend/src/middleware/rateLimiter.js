const rateLimit = require('express-rate-limit');
const { ApiError } = require('./errorHandler');
const logger = require('../utils/logger');

/**
 * Create a custom error handler for rate limiting
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
const rateLimitHandler = (req, res) => {
  const error = ApiError.tooManyRequests('Too many requests, please try again later', {
    retryAfter: res.getHeader('Retry-After') || 60,
    limit: res.getHeader('X-RateLimit-Limit'),
    remaining: 0,
    reset: res.getHeader('X-RateLimit-Reset'),
  });
  
  logger.warn('Rate limit exceeded', {
    ip: req.ip,
    path: req.path,
    method: req.method,
    userId: req.user?.id || 'unauthenticated',
  });
  
  res.status(429).json({
    status: 'error',
    statusCode: 429,
    message: error.message,
    errorCode: error.errorCode,
    details: error.details,
  });
};

/**
 * Default rate limiter for general API endpoints
 * Limits to 100 requests per minute per IP
 */
const defaultRateLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 100, // 100 requests per minute
  standardHeaders: true, // Return rate limit info in the `RateLimit-*` headers
  legacyHeaders: false, // Disable the `X-RateLimit-*` headers
  handler: rateLimitHandler,
  keyGenerator: (req) => {
    // Use IP address as the default key
    return req.ip;
  },
  skip: (req) => {
    // Skip rate limiting for health check endpoint
    return req.path === '/health';
  },
});

/**
 * Strict rate limiter for authentication endpoints
 * Limits to 10 requests per minute per IP
 */
const authRateLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 10, // 10 requests per minute
  standardHeaders: true,
  legacyHeaders: false,
  handler: rateLimitHandler,
  keyGenerator: (req) => {
    // Use IP address for auth endpoints
    return req.ip;
  },
});

/**
 * Rate limiter for upload endpoints
 * Limits to 20 uploads per hour per user
 */
const uploadRateLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 20, // 20 uploads per hour
  standardHeaders: true,
  legacyHeaders: false,
  handler: rateLimitHandler,
  keyGenerator: (req) => {
    // Use user ID if available, otherwise IP
    return req.user?.id || req.ip;
  },
});

/**
 * Rate limiter for transcription endpoints
 * Limits to 50 transcription requests per day per user
 */
const transcriptionRateLimiter = rateLimit({
  windowMs: 24 * 60 * 60 * 1000, // 24 hours
  max: 50, // 50 transcriptions per day
  standardHeaders: true,
  legacyHeaders: false,
  handler: rateLimitHandler,
  keyGenerator: (req) => {
    // Use user ID if available, otherwise IP
    return req.user?.id || req.ip;
  },
});

module.exports = {
  defaultRateLimiter,
  authRateLimiter,
  uploadRateLimiter,
  transcriptionRateLimiter,
};
