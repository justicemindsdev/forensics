require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const compression = require('compression');
const { createServer } = require('http');
const { Server } = require('socket.io');
const routes = require('./routes');
const { errorHandler } = require('./middleware/errorHandler');
const { defaultRateLimiter } = require('./middleware/rateLimiter');
const { setupRabbitMQ } = require('./services/rabbitmq');
const { setupRedis } = require('./services/redis');
const { setupMinIO } = require('./services/minio');
const { setupDatabase } = require('./database');
const logger = require('./utils/logger');

// Initialize Express app
const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: process.env.FRONTEND_URL || 'http://localhost:8000',
    methods: ['GET', 'POST'],
    credentials: true
  }
});

// Security middleware
app.use(helmet()); // Security headers
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:8000',
  credentials: true
}));

// Logging middleware
app.use(morgan('dev', { stream: logger.stream }));

// Performance middleware
app.use(compression()); // Compress responses

// Body parsing middleware
app.use(express.json({ limit: '10mb' })); // Parse JSON bodies with size limit
app.use(express.urlencoded({ extended: true, limit: '10mb' })); // Parse URL-encoded bodies with size limit

// Apply rate limiting to all routes
app.use(defaultRateLimiter);

// API Routes
app.use('/api', routes);

// Socket.io connection
io.on('connection', (socket) => {
  logger.info(`Socket connected: ${socket.id}`);
  
  socket.on('disconnect', () => {
    logger.info(`Socket disconnected: ${socket.id}`);
  });
});

// Error handling middleware (must be after routes)
app.use(errorHandler);

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Start server
const PORT = process.env.PORT || 3000;

const startServer = async () => {
  try {
    // Initialize services
    await setupDatabase();
    await setupRabbitMQ();
    await setupRedis();
    await setupMinIO();
    
    // Start HTTP server
    httpServer.listen(PORT, () => {
      logger.info(`Server running on port ${PORT} in ${process.env.NODE_ENV || 'development'} mode`);
    });
  } catch (error) {
    logger.error('Failed to start server:', error);
    process.exit(1);
  }
};

// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
  logger.error('Uncaught Exception:', error);
  // Graceful shutdown
  httpServer.close(() => {
    logger.info('Server closed due to uncaught exception');
    process.exit(1);
  });
  
  // If graceful shutdown fails, force exit after 10 seconds
  setTimeout(() => {
    logger.error('Forced shutdown after uncaught exception');
    process.exit(1);
  }, 10000);
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
  logger.error('Unhandled Rejection at:', promise, 'reason:', reason);
  // Graceful shutdown
  httpServer.close(() => {
    logger.info('Server closed due to unhandled rejection');
    process.exit(1);
  });
  
  // If graceful shutdown fails, force exit after 10 seconds
  setTimeout(() => {
    logger.error('Forced shutdown after unhandled rejection');
    process.exit(1);
  }, 10000);
});

// Handle SIGTERM signal (e.g., from Docker)
process.on('SIGTERM', () => {
  logger.info('SIGTERM signal received');
  httpServer.close(() => {
    logger.info('Server closed gracefully');
    process.exit(0);
  });
  
  // If graceful shutdown fails, force exit after 10 seconds
  setTimeout(() => {
    logger.info('Forced shutdown after SIGTERM');
    process.exit(0);
  }, 10000);
});

// Start the server
startServer();

module.exports = { app, httpServer };
