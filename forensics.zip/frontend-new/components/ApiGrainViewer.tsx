import React, { useState, useEffect } from 'react';
import axios from 'axios';

interface ApiGrainSource {
  name: string;
  url: string;
}

interface ApiGrainViewerProps {
  sourceName?: string; // Optional: specific source to display
  showAllSources?: boolean; // Optional: show all sources
}

/**
 * Component to display data from API Grain sources
 */
const ApiGrainViewer: React.FC<ApiGrainViewerProps> = ({ 
  sourceName, 
  showAllSources = false 
}) => {
  const [sources, setSources] = useState<ApiGrainSource[]>([]);
  const [selectedSource, setSelectedSource] = useState<string | null>(sourceName || null);
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch available sources on component mount
  useEffect(() => {
    const fetchSources = async () => {
      try {
        const response = await axios.get('/api/apigrain/all');
        const sourceData = response.data;
        
        // Convert to array of sources
        const sourceArray = Object.entries(sourceData).map(([name, data]: [string, any]) => ({
          name,
          url: data.url || 'URL not available',
          hasError: data.error || false
        }));
        
        setSources(sourceArray);
        
        // If no source is selected and we have sources, select the first one
        if (!selectedSource && sourceArray.length > 0 && !showAllSources) {
          setSelectedSource(sourceArray[0].name);
        }
      } catch (err) {
        setError('Failed to fetch API sources');
        console.error('Error fetching API sources:', err);
      }
    };
    
    fetchSources();
  }, [selectedSource, showAllSources]);

  // Fetch data when a source is selected
  useEffect(() => {
    const fetchData = async () => {
      if (!selectedSource && !showAllSources) return;
      
      setLoading(true);
      setError(null);
      
      try {
        if (showAllSources) {
          const response = await axios.get('/api/apigrain/all');
          setData(response.data);
        } else if (selectedSource) {
          const response = await axios.get(`/api/apigrain/${selectedSource}`);
          setData(response.data);
        }
      } catch (err) {
        setError('Failed to fetch data from API source');
        console.error('Error fetching data:', err);
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
  }, [selectedSource, showAllSources]);

  // Handle source selection change
  const handleSourceChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedSource(event.target.value);
  };

  return (
    <div className="api-grain-viewer">
      <h2 className="text-xl font-bold mb-4">API Grain Data Viewer</h2>
      
      {/* Source selector */}
      {!showAllSources && sources.length > 0 && (
        <div className="mb-4">
          <label htmlFor="source-selector" className="block text-sm font-medium mb-1">
            Select API Source:
          </label>
          <select
            id="source-selector"
            value={selectedSource || ''}
            onChange={handleSourceChange}
            className="w-full p-2 border rounded"
          >
            <option value="" disabled>Select a source</option>
            {sources.map((source) => (
              <option key={source.name} value={source.name}>
                {source.name} {source.hasError ? '(Error)' : ''}
              </option>
            ))}
          </select>
        </div>
      )}
      
      {/* Loading state */}
      {loading && (
        <div className="text-center py-4">
          <p>Loading data...</p>
        </div>
      )}
      
      {/* Error state */}
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          <p>{error}</p>
        </div>
      )}
      
      {/* Data display */}
      {!loading && !error && data && (
        <div className="mt-4">
          <h3 className="text-lg font-semibold mb-2">
            {showAllSources ? 'All Sources Data' : `Data from ${selectedSource}`}
          </h3>
          
          {showAllSources ? (
            // Display all sources
            <div>
              {Object.entries(data).map(([name, sourceData]: [string, any]) => (
                <div key={name} className="mb-6 p-4 border rounded">
                  <h4 className="text-md font-medium mb-2">{name}</h4>
                  <p className="text-sm text-gray-600 mb-2">
                    URL: {sourceData.url || 'N/A'}
                  </p>
                  
                  {sourceData.error ? (
                    <p className="text-red-600">Error: {sourceData.message}</p>
                  ) : (
                    <pre className="bg-gray-100 p-3 rounded overflow-auto max-h-60">
                      {JSON.stringify(sourceData.data || sourceData, null, 2)}
                    </pre>
                  )}
                </div>
              ))}
            </div>
          ) : (
            // Display single source
            <div>
              <p className="text-sm text-gray-600 mb-2">
                URL: {data.url || 'N/A'}
              </p>
              <pre className="bg-gray-100 p-3 rounded overflow-auto max-h-96">
                {JSON.stringify(data.data || data, null, 2)}
              </pre>
            </div>
          )}
        </div>
      )}
      
      {/* No data state */}
      {!loading && !error && !data && (
        <div className="text-center py-4">
          <p>No data available. Please select a source.</p>
        </div>
      )}
    </div>
  );
};

export default ApiGrainViewer;
