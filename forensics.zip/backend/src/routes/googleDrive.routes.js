const express = require('express');
const { body, param, query } = require('express-validator');
const googleDriveController = require('../controllers/googleDrive.controller');
const { validateRequest } = require('../middleware/validateRequest');
const { authenticate } = require('../middleware/authenticate');

const router = express.Router();

// Apply authentication middleware to all routes
router.use(authenticate);

/**
 * @route GET /api/integrations/google-drive/files
 * @desc Get all Google Drive files for the current user
 * @access Private
 */
router.get(
  '/files',
  [
    query('mimeType').optional(),
    query('pageSize').optional().isInt({ min: 1, max: 100 }).withMessage('Page size must be between 1 and 100'),
    query('pageToken').optional(),
    validateRequest
  ],
  googleDriveController.getGoogleDriveFiles
);

/**
 * @route POST /api/integrations/google-drive/files/:fileId/import
 * @desc Import a Google Drive file
 * @access Private
 */
router.post(
  '/files/:fileId/import',
  [
    param('fileId').not().isEmpty().withMessage('File ID is required'),
    body('title').optional(),
    body('description').optional(),
    validateRequest
  ],
  googleDriveController.importGoogleDriveFile
);

/**
 * @route POST /api/integrations/google-drive/auth
 * @desc Authenticate with Google Drive
 * @access Private
 */
router.post(
  '/auth',
  [
    body('code').not().isEmpty().withMessage('Authorization code is required'),
    validateRequest
  ],
  googleDriveController.googleDriveAuth
);

/**
 * @route GET /api/integrations/google-drive/auth/callback
 * @desc Google Drive OAuth callback
 * @access Public
 */
router.get('/auth/callback', googleDriveController.googleDriveAuthCallback);

/**
 * @route GET /api/integrations/google-drive/status
 * @desc Check Google Drive integration status
 * @access Private
 */
router.get('/status', googleDriveController.getGoogleDriveStatus);

/**
 * @route DELETE /api/integrations/google-drive/disconnect
 * @desc Disconnect Google Drive integration
 * @access Private
 */
router.delete('/disconnect', googleDriveController.disconnectGoogleDrive);

/**
 * @route GET /api/integrations/google-drive/search
 * @desc Search Google Drive files
 * @access Private
 */
router.get(
  '/search',
  [
    query('q').not().isEmpty().withMessage('Search query is required'),
    query('mimeType').optional(),
    validateRequest
  ],
  googleDriveController.searchGoogleDriveFiles
);

module.exports = router;
