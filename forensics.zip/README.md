# Justice Minds Forensic Transcription Service

An AI-powered meeting assistant that records, transcribes, and analyzes conversations. This service supports ingestion from various sources including direct uploads, Zoom recordings, and Google Drive videos, while maintaining relative video timing for accurate transcription.

## Project Overview

Justice Minds Forensic Transcription service functions as an AI-powered meeting assistant that:
- Records conversations in real-time
- Transcribes audio/video with accurate timestamps
- Analyzes content using NLP for insights
- Extracts action items and key takeaways
- Integrates with external tools (Slack, CRM, Email)

## Architecture

The project is structured into six main components:

1. **User Interaction & Frontend**
   - React.js/Next.js for UI
   - WebRTC for real-time recording
   - State management with Redux/Context API

2. **Backend & Real-Time Recording**
   - Node.js/Express for API
   - WebSockets for real-time updates
   - Message queue for asynchronous processing
   - Support for Zoom and Google Drive integration

3. **Transcription & AI Processing**
   - OpenAI Whisper/Google Speech-to-Text for transcription
   - NLP for summarization & sentiment analysis
   - ML pipeline for action item extraction

4. **Data Storage & Retrieval**
   - PostgreSQL/MongoDB for structured data
   - Vector database for semantic search
   - Cloud storage for media files

5. **AI-Powered Insights & Automation**
   - AI-generated summaries and coaching insights
   - Semantic search for querying past meetings
   - Automated follow-ups and action plans

6. **Integration with External Tools**
   - CRM integration (Salesforce, HubSpot)
   - Communication platforms (Slack, Microsoft Teams)
   - Calendar sync (Google Calendar, Outlook)

## Getting Started

### Prerequisites

- Node.js (v16+)
- Docker and Docker Compose
- Git
- AWS account (for production deployment)

### Installation

1. Clone the repository:
   ```
   git clone https://github.com/your-organization/justice-minds-forensics.git
   cd justice-minds-forensics
   ```

2. Set up environment variables:
   ```
   # For local development with manual .env file
   cp .env.example .env
   # Edit .env with your configuration
   
   # OR use AWS Secrets Manager (recommended)
   npm run fetch-secrets:dev
   ```

3. Start the development environment:
   ```
   docker-compose up -d
   ```

4. Install dependencies:
   ```
   npm run install:all
   ```

5. Start the development servers:
   ```
   npm run dev
   ```

## Secrets Management

Justice Minds uses AWS Secrets Manager for secure handling of sensitive configuration values:

### Local Development

For local development, you can fetch secrets from AWS Secrets Manager:

```
npm run fetch-secrets:dev  # Development environment
npm run fetch-secrets:prod # Production environment
```

This will create a `.env` file with the necessary environment variables.

### Production Deployment

In production, secrets are injected directly into the container environment variables using AWS ECS task definitions. See the [infrastructure README](infrastructure/README.md) for details.

## Project Structure

```
justice-minds-forensics/
├── backend/             # Node.js/Express API
│   ├── src/             # Source code
│   │   ├── database/    # Database connection and models
│   │   ├── middleware/  # Express middleware
│   │   ├── routes/      # API routes
│   │   ├── services/    # Business logic and external services
│   │   └── utils/       # Utility functions
│   └── Dockerfile.dev   # Development Docker configuration
├── frontend/            # React UI
│   ├── public/          # Static assets
│   ├── src/             # Source code
│   │   ├── components/  # React components
│   │   ├── pages/       # Page components
│   │   ├── services/    # API client and service functions
│   │   ├── store/       # Redux store and slices
│   │   └── layouts/     # Layout components
│   └── Dockerfile.dev   # Development Docker configuration
├── ai-models/           # AI transcription and NLP models
├── database/            # Database schemas and migrations
├── infrastructure/      # Infrastructure as code
│   ├── ecs/             # AWS ECS configurations
│   ├── terraform/       # Terraform configurations
│   └── README.md        # Infrastructure documentation
├── scripts/             # Utility scripts
│   └── fetchSecrets.ts  # Script to fetch secrets from AWS
├── .github/workflows/   # GitHub Actions workflows
├── docker-compose.yml   # Docker Compose configuration
└── docs/                # Documentation
```

## Deployment

The application can be deployed to AWS using the provided GitHub Actions workflow and infrastructure configurations. See the [infrastructure README](infrastructure/README.md) for details.

## Contributing

Please read [CONTRIBUTING.md](CONTRIBUTING.md) for details on our code of conduct and the process for submitting pull requests.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
# forensics
