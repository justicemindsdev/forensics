import React, { useState, useEffect } from 'react';
import axios from 'axios';

interface Recording {
  id: string;
  title: string;
  url: string;
  start_datetime: string;
  end_datetime: string;
  public_thumbnail_url?: string;
}

interface User {
  name: string;
  id: string;
}

interface Highlight {
  id: string;
  recording_id: string;
  text: string;
  timestamp: number;
  duration: number;
  url: string;
  thumbnail_url?: string;
  created_datetime: string;
}

/**
 * Grain API Page
 * 
 * This page displays data from the Grain API, including:
 * - User information
 * - Recordings
 * - Recording details
 */
export default function GrainApiPage() {
  const [user, setUser] = useState<User | null>(null);
  const [recordings, setRecordings] = useState<Recording[]>([]);
  const [selectedRecording, setSelectedRecording] = useState<string | null>(null);
  const [recordingDetails, setRecordingDetails] = useState<any | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Fetch user and recordings on component mount
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        setError(null);

        // Fetch user data
        const userResponse = await axios.get('/api/apigrain/grain.com?endpoint=me');
        setUser(userResponse.data);

        // Fetch recordings
        const recordingsResponse = await axios.get('/api/apigrain/grain.com');
        setRecordings(recordingsResponse.data.recordings || []);
      } catch (err) {
        console.error('Error fetching Grain API data:', err);
        setError('Failed to fetch data from Grain API');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  // Fetch recording details when a recording is selected
  useEffect(() => {
    const fetchRecordingDetails = async () => {
      if (!selectedRecording) {
        setRecordingDetails(null);
        return;
      }

      try {
        setLoading(true);
        setError(null);

        const response = await axios.get(`/api/apigrain/grain.com?recordingId=${selectedRecording}&include_highlights=true&include_participants=true`);
        setRecordingDetails(response.data);
      } catch (err) {
        console.error(`Error fetching recording details for ${selectedRecording}:`, err);
        setError('Failed to fetch recording details');
      } finally {
        setLoading(false);
      }
    };

    fetchRecordingDetails();
  }, [selectedRecording]);

  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString();
  };

  // Handle recording selection
  const handleRecordingClick = (recordingId: string) => {
    setSelectedRecording(recordingId === selectedRecording ? null : recordingId);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Grain API Integration</h1>

      {/* Loading state */}
      {loading && (
        <div className="text-center py-4">
          <p>Loading data...</p>
        </div>
      )}

      {/* Error state */}
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          <p>{error}</p>
        </div>
      )}

      {/* User information */}
      {user && (
        <div className="mb-8 p-4 border rounded-lg bg-gray-50">
          <h2 className="text-xl font-semibold mb-2">User Information</h2>
          <p><strong>Name:</strong> {user.name}</p>
          <p><strong>ID:</strong> {user.id}</p>
        </div>
      )}

      {/* Recordings list */}
      <div className="mb-8">
        <h2 className="text-2xl font-semibold mb-4">Recordings</h2>
        
        {recordings.length === 0 && !loading ? (
          <p>No recordings found.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {recordings.map((recording) => (
              <div 
                key={recording.id}
                className={`border rounded-lg p-4 cursor-pointer transition-colors ${
                  selectedRecording === recording.id ? 'bg-blue-50 border-blue-300' : 'hover:bg-gray-50'
                }`}
                onClick={() => handleRecordingClick(recording.id)}
              >
                <h3 className="text-lg font-medium mb-2">{recording.title}</h3>
                <p className="text-sm text-gray-600 mb-1">
                  <strong>Start:</strong> {formatDate(recording.start_datetime)}
                </p>
                <p className="text-sm text-gray-600 mb-2">
                  <strong>End:</strong> {formatDate(recording.end_datetime)}
                </p>
                {recording.public_thumbnail_url && (
                  <img 
                    src={recording.public_thumbnail_url} 
                    alt={recording.title}
                    className="w-full h-32 object-cover rounded"
                  />
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Recording details */}
      {recordingDetails && (
        <div className="border rounded-lg p-6">
          <h2 className="text-2xl font-semibold mb-4">Recording Details: {recordingDetails.title}</h2>
          
          {/* Recording information */}
          <div className="mb-6">
            <h3 className="text-xl font-medium mb-2">Information</h3>
            <p><strong>ID:</strong> {recordingDetails.id}</p>
            <p><strong>Start:</strong> {formatDate(recordingDetails.start_datetime)}</p>
            <p><strong>End:</strong> {formatDate(recordingDetails.end_datetime)}</p>
            <p>
              <strong>URL:</strong>{' '}
              <a 
                href={recordingDetails.url} 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-blue-600 hover:underline"
              >
                {recordingDetails.url}
              </a>
            </p>
          </div>
          
          {/* Participants */}
          {recordingDetails.participants && recordingDetails.participants.length > 0 && (
            <div className="mb-6">
              <h3 className="text-xl font-medium mb-2">Participants</h3>
              <ul className="list-disc pl-5">
                {recordingDetails.participants.map((participant: any, index: number) => (
                  <li key={index}>
                    {participant.name} {participant.email ? `(${participant.email})` : ''} - {participant.scope}
                  </li>
                ))}
              </ul>
            </div>
          )}
          
          {/* Owners */}
          {recordingDetails.owners && recordingDetails.owners.length > 0 && (
            <div className="mb-6">
              <h3 className="text-xl font-medium mb-2">Owners</h3>
              <ul className="list-disc pl-5">
                {recordingDetails.owners.map((owner: string, index: number) => (
                  <li key={index}>{owner}</li>
                ))}
              </ul>
            </div>
          )}
          
          {/* Tags */}
          {recordingDetails.tags && recordingDetails.tags.length > 0 && (
            <div className="mb-6">
              <h3 className="text-xl font-medium mb-2">Tags</h3>
              <div className="flex flex-wrap gap-2">
                {recordingDetails.tags.map((tag: string, index: number) => (
                  <span 
                    key={index}
                    className="bg-gray-200 text-gray-800 px-2 py-1 rounded-full text-sm"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          )}
          
          {/* Highlights */}
          {recordingDetails.highlights && recordingDetails.highlights.length > 0 && (
            <div>
              <h3 className="text-xl font-medium mb-2">Highlights</h3>
              <div className="space-y-4">
                {recordingDetails.highlights.map((highlight: Highlight) => (
                  <div key={highlight.id} className="border rounded p-4">
                    <p className="font-medium mb-2">{highlight.text}</p>
                    <p className="text-sm text-gray-600 mb-2">
                      <strong>Timestamp:</strong> {Math.floor(highlight.timestamp / 60000)}:{String(Math.floor((highlight.timestamp % 60000) / 1000)).padStart(2, '0')}
                    </p>
                    <p className="text-sm text-gray-600 mb-2">
                      <strong>Duration:</strong> {Math.floor(highlight.duration / 1000)} seconds
                    </p>
                    <p className="text-sm text-gray-600 mb-2">
                      <strong>Created:</strong> {formatDate(highlight.created_datetime)}
                    </p>
                    {highlight.thumbnail_url && (
                      <img 
                        src={highlight.thumbnail_url} 
                        alt={highlight.text}
                        className="w-full h-32 object-cover rounded mt-2"
                      />
                    )}
                    <div className="mt-2">
                      <a 
                        href={highlight.url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:underline text-sm"
                      >
                        View Highlight
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
