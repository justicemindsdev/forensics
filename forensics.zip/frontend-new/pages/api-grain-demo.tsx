import React from 'react';
import ApiGrainViewer from '../components/ApiGrainViewer';

/**
 * Demo page for API Grain functionality
 * This page demonstrates how to use the API Grain system
 */
export default function ApiGrainDemo() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">API Grain Demo</h1>
      
      <div className="mb-8">
        <h2 className="text-2xl font-semibold mb-4">About API Grain</h2>
        <p className="mb-4">
          API Grain is a system that allows you to use external API endpoints as data sources
          by simply adding files to the <code className="bg-gray-100 px-1 py-0.5 rounded">frontend-new/apigrain</code> directory.
        </p>
        <p className="mb-4">
          Each file in this directory contains a URL to an API endpoint. The filename is used
          as the identifier for the API source.
        </p>
        <p>
          For example, the file <code className="bg-gray-100 px-1 py-0.5 rounded">grain.com</code> contains
          the URL to the Grain Public API documentation.
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="border rounded-lg p-6 shadow-sm">
          <h2 className="text-2xl font-semibold mb-4">Single Source View</h2>
          <p className="mb-4">
            This example shows how to display data from a single API source.
          </p>
          <div className="mt-6">
            <ApiGrainViewer />
          </div>
        </div>
        
        <div className="border rounded-lg p-6 shadow-sm">
          <h2 className="text-2xl font-semibold mb-4">All Sources View</h2>
          <p className="mb-4">
            This example shows how to display data from all available API sources.
          </p>
          <div className="mt-6">
            <ApiGrainViewer showAllSources={true} />
          </div>
        </div>
      </div>
      
      <div className="mt-12 p-6 border rounded-lg bg-gray-50">
        <h2 className="text-2xl font-semibold mb-4">How to Use API Grain</h2>
        
        <div className="mb-6">
          <h3 className="text-xl font-medium mb-2">1. Add a new API source</h3>
          <p className="mb-2">
            To add a new API source, create a file in the <code className="bg-gray-100 px-1 py-0.5 rounded">frontend-new/apigrain</code> directory.
            The filename will be used as the identifier for the API source, and the file should contain the URL to the API endpoint.
          </p>
          <pre className="bg-gray-100 p-3 rounded">
            # Example: Adding a new API source
            echo "https://api.example.com/data" > frontend-new/apigrain/example-api.com
          </pre>
        </div>
        
        <div className="mb-6">
          <h3 className="text-xl font-medium mb-2">2. Use the API in your code</h3>
          <p className="mb-2">
            You can use the API Grain utilities to fetch data from your API sources:
          </p>
          <pre className="bg-gray-100 p-3 rounded overflow-auto">
{`// Import the API Grain utilities
import { fetchFromSource } from '../apigrain/apiGrainUtils';

// Fetch data from a specific source
async function fetchData() {
  try {
    const data = await fetchFromSource('example-api.com');
    console.log('Data:', data);
  } catch (error) {
    console.error('Error:', error);
  }
}

// Or use the ApiGrainViewer component
import ApiGrainViewer from '../components/ApiGrainViewer';

function MyComponent() {
  return (
    <div>
      <h1>My API Data</h1>
      <ApiGrainViewer sourceName="example-api.com" />
    </div>
  );
}`}
          </pre>
        </div>
        
        <div>
          <h3 className="text-xl font-medium mb-2">3. Use the API routes</h3>
          <p className="mb-2">
            You can also use the API routes to fetch data from your API sources:
          </p>
          <pre className="bg-gray-100 p-3 rounded overflow-auto">
{`// Fetch data from a specific source
fetch('/api/apigrain/example-api.com')
  .then(response => response.json())
  .then(data => console.log('Data:', data))
  .catch(error => console.error('Error:', error));

// Fetch data from all sources
fetch('/api/apigrain/all')
  .then(response => response.json())
  .then(data => console.log('All sources data:', data))
  .catch(error => console.error('Error:', error));`}
          </pre>
        </div>
      </div>
    </div>
  );
}
