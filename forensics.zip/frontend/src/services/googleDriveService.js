import apiClient from './apiClient';

/**
 * Google Drive service for handling Google Drive integration
 * Note: This is a placeholder service with minimal implementation
 * Full integration will be implemented in a later phase
 */
const googleDriveService = {
  /**
   * Get Google Drive integration status
   * @returns {Promise<Object>} - Google Drive status
   */
  getGoogleDriveStatus: async () => {
    const response = await apiClient.get('/integrations/google-drive/status');
    return response.data;
  },
  
  /**
   * Authenticate with Google Drive using OAuth
   * @param {string} code - OAuth authorization code
   * @returns {Promise<Object>} - Authentication result
   */
  authenticateGoogleDrive: async (code) => {
    const response = await apiClient.post('/integrations/google-drive/auth', { code });
    return response.data;
  },
  
  /**
   * Disconnect Google Drive integration
   * @returns {Promise<void>}
   */
  disconnectGoogleDrive: async () => {
    await apiClient.delete('/integrations/google-drive/disconnect');
  },
  
  /**
   * Get Google Drive files
   * @param {string} mimeType - Filter by MIME type (optional)
   * @param {number} pageSize - Number of items per page (optional)
   * @param {string} pageToken - Token for pagination (optional)
   * @returns {Promise<Object>} - List of Google Drive files and pagination info
   */
  getGoogleDriveFiles: async (mimeType, pageSize, pageToken) => {
    const response = await apiClient.get('/integrations/google-drive/files', {
      params: {
        mimeType,
        pageSize,
        pageToken,
      },
    });
    return response.data;
  },
  
  /**
   * Search Google Drive files
   * @param {string} query - Search query
   * @param {string} mimeType - Filter by MIME type (optional)
   * @returns {Promise<Array>} - Search results
   */
  searchGoogleDriveFiles: async (query, mimeType) => {
    const response = await apiClient.get('/integrations/google-drive/search', {
      params: {
        q: query,
        mimeType,
      },
    });
    return response.data;
  },
  
  /**
   * Import a Google Drive file
   * @param {string} fileId - Google Drive file ID
   * @param {string} title - File title (optional)
   * @param {string} description - File description (optional)
   * @returns {Promise<Object>} - Imported file data
   */
  importGoogleDriveFile: async (fileId, title = '', description = '') => {
    const response = await apiClient.post(`/integrations/google-drive/files/${fileId}/import`, {
      title,
      description,
    });
    return response.data;
  },
};

export default googleDriveService;
