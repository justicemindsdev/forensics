const amqp = require('amqplib');
const logger = require('../utils/logger');

let connection = null;
let channel = null;

/**
 * Initialize RabbitMQ connection and channel
 */
const setupRabbitMQ = async () => {
  try {
    // Connect to RabbitMQ server
    connection = await amqp.connect(process.env.RABBITMQ_URL);
    logger.info('Connected to RabbitMQ');
    
    // Create a channel
    channel = await connection.createChannel();
    logger.info('RabbitMQ channel created');
    
    // Define queues
    await channel.assertQueue('transcription-queue', { durable: true });
    await channel.assertQueue('notification-queue', { durable: true });
    
    // Handle connection close
    connection.on('close', () => {
      logger.warn('RabbitMQ connection closed');
      setTimeout(setupRabbitMQ, 5000); // Try to reconnect after 5 seconds
    });
    
    // Handle errors
    connection.on('error', (err) => {
      logger.error('RabbitMQ connection error:', err);
      setTimeout(setupRabbitMQ, 5000); // Try to reconnect after 5 seconds
    });
    
    return { connection, channel };
  } catch (error) {
    logger.error('Failed to connect to RabbitMQ:', error);
    // Retry connection after 5 seconds
    setTimeout(setupRabbitMQ, 5000);
  }
};

/**
 * Send a message to a queue
 * @param {string} queue - Queue name
 * @param {object} message - Message to send
 */
const sendToQueue = async (queue, message) => {
  try {
    if (!channel) {
      throw new Error('RabbitMQ channel not initialized');
    }
    
    await channel.sendToQueue(
      queue,
      Buffer.from(JSON.stringify(message)),
      { persistent: true }
    );
    
    logger.debug(`Message sent to queue ${queue}`);
    return true;
  } catch (error) {
    logger.error(`Failed to send message to queue ${queue}:`, error);
    throw error;
  }
};

/**
 * Consume messages from a queue
 * @param {string} queue - Queue name
 * @param {function} callback - Callback function to process messages
 */
const consumeFromQueue = async (queue, callback) => {
  try {
    if (!channel) {
      throw new Error('RabbitMQ channel not initialized');
    }
    
    await channel.consume(queue, async (msg) => {
      if (msg) {
        try {
          const content = JSON.parse(msg.content.toString());
          await callback(content);
          channel.ack(msg);
        } catch (error) {
          logger.error(`Error processing message from queue ${queue}:`, error);
          // Reject the message and requeue it
          channel.nack(msg, false, true);
        }
      }
    });
    
    logger.info(`Consumer started for queue ${queue}`);
    return true;
  } catch (error) {
    logger.error(`Failed to start consumer for queue ${queue}:`, error);
    throw error;
  }
};

/**
 * Close RabbitMQ connection
 */
const closeRabbitMQ = async () => {
  try {
    if (channel) {
      await channel.close();
      logger.info('RabbitMQ channel closed');
    }
    
    if (connection) {
      await connection.close();
      logger.info('RabbitMQ connection closed');
    }
  } catch (error) {
    logger.error('Error closing RabbitMQ connection:', error);
    throw error;
  }
};

module.exports = {
  setupRabbitMQ,
  sendToQueue,
  consumeFromQueue,
  closeRabbitMQ
};
