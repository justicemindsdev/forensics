# Justice Minds Infrastructure

This directory contains infrastructure-as-code configurations for deploying the Justice Minds Forensic Transcription service to AWS.

## Directory Structure

- `ecs/` - AWS ECS task definitions and related configurations
- `terraform/` - Terraform configurations for provisioning AWS resources

## AWS Secrets Manager Integration

The Justice Minds application uses AWS Secrets Manager to securely store and retrieve sensitive configuration values. This approach ensures that secrets are never stored in code or configuration files.

### Setting Up Secrets with Terraform

1. Navigate to the terraform directory:
   ```
   cd infrastructure/terraform
   ```

2. Initialize Terraform:
   ```
   terraform init
   ```

3. Create a `terraform.tfvars` file with your secret values:
   ```
   aws_region         = "us-east-1"
   environment        = "dev"  # or "prod" for production
   
   # Database
   database_url       = "postgres://user:password@hostname:5432/justice_minds"
   
   # Redis
   redis_url          = "redis://hostname:6379"
   
   # RabbitMQ
   rabbitmq_url       = "amqp://user:password@hostname:5672"
   
   # JWT
   jwt_secret         = "your-secure-jwt-secret"
   
   # MinIO / S3
   minio_endpoint     = "s3.amazonaws.com"
   minio_port         = "443"
   minio_access_key   = "your-access-key"
   minio_secret_key   = "your-secret-key"
   minio_bucket       = "justice-minds-bucket"
   
   # External APIs
   openai_api_key     = "your-openai-api-key"
   
   # Zoom API
   zoom_api_key       = "your-zoom-api-key"
   zoom_api_secret    = "your-zoom-api-secret"
   zoom_verification_token = "your-zoom-verification-token"
   
   # Google Drive API
   google_client_id   = "your-google-client-id"
   google_client_secret = "your-google-client-secret"
   ```

4. Apply the Terraform configuration:
   ```
   terraform apply
   ```

5. Note the output `secret_arn` value, which you'll need for ECS task definitions.

### Accessing Secrets in the Application

The application can access secrets in two ways:

1. **Development Environment**: Use the `fetchSecrets.ts` script to download secrets to a local `.env` file:
   ```
   npm run fetch-secrets:dev
   ```

2. **Production Environment**: In AWS ECS, secrets are injected directly into the container environment variables using the ARN format:
   ```
   arn:aws:secretsmanager:region:account-id:secret:justice-minds/prod:SECRET_NAME
   ```

## AWS ECS Deployment

The application is deployed to AWS ECS using the task definition in `ecs/task-definition.json`. This task definition includes:

- Backend container
- Frontend container
- AI Worker container

Each container is configured to access the necessary secrets from AWS Secrets Manager.

### Updating the Task Definition

1. Update the `task-definition.json` file with your specific configuration.
2. Replace the placeholder ARNs with your actual ARNs:
   - `executionRoleArn` - The IAM role that allows ECS to pull container images and secrets
   - `taskRoleArn` - The IAM role that allows the containers to access AWS services
   - Secret ARNs - The ARNs of your secrets in AWS Secrets Manager

3. Deploy the updated task definition using the GitHub Actions workflow or the AWS CLI:
   ```
   aws ecs register-task-definition --cli-input-json file://infrastructure/ecs/task-definition.json
   ```

## GitHub Actions Workflow

The GitHub Actions workflow in `.github/workflows/deploy.yml` automates the deployment process:

1. Runs tests
2. Fetches secrets from AWS Secrets Manager
3. Builds the application
4. Builds and pushes Docker images to Amazon ECR
5. Deploys the updated task definition to AWS ECS

### Required GitHub Secrets

To use the GitHub Actions workflow, you need to set the following secrets in your GitHub repository:

- `AWS_ACCESS_KEY_ID` - AWS access key with permissions to access ECR, ECS, and Secrets Manager
- `AWS_SECRET_ACCESS_KEY` - Corresponding AWS secret key
- `AWS_REGION` - AWS region where your resources are located
