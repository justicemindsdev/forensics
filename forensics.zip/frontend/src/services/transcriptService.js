import apiClient from './apiClient';

/**
 * Transcript service for handling transcript-related operations
 */
const transcriptService = {
  /**
   * Get all transcripts
   * @param {number} page - Page number (optional)
   * @param {number} limit - Number of items per page (optional)
   * @returns {Promise<Array>} - List of transcripts
   */
  getTranscripts: async (page = 1, limit = 10) => {
    const response = await apiClient.get('/transcripts', {
      params: { page, limit },
    });
    return response.data;
  },
  
  /**
   * Get a transcript by ID
   * @param {string} id - Transcript ID
   * @returns {Promise<Object>} - Transcript data
   */
  getTranscriptById: async (id) => {
    const response = await apiClient.get(`/transcripts/${id}`);
    return response.data;
  },
  
  /**
   * Get insights for a transcript
   * @param {string} id - Transcript ID
   * @returns {Promise<Object>} - Transcript insights
   */
  getTranscriptInsights: async (id) => {
    const response = await apiClient.get(`/transcripts/${id}/insights`);
    return response.data;
  },
  
  /**
   * Get action items for a transcript
   * @param {string} id - Transcript ID
   * @returns {Promise<Array>} - List of action items
   */
  getTranscriptActionItems: async (id) => {
    const response = await apiClient.get(`/transcripts/${id}/action-items`);
    return response.data;
  },
  
  /**
   * Get summary for a transcript
   * @param {string} id - Transcript ID
   * @returns {Promise<Object>} - Transcript summary
   */
  getTranscriptSummary: async (id) => {
    const response = await apiClient.get(`/transcripts/${id}/summary`);
    return response.data;
  },
  
  /**
   * Get sentiment analysis for a transcript
   * @param {string} id - Transcript ID
   * @returns {Promise<Object>} - Sentiment analysis
   */
  getTranscriptSentiment: async (id) => {
    const response = await apiClient.get(`/transcripts/${id}/sentiment`);
    return response.data;
  },
  
  /**
   * Share a transcript with other users
   * @param {string} id - Transcript ID
   * @param {Array<string>} emails - List of email addresses
   * @returns {Promise<Object>} - Response data
   */
  shareTranscript: async (id, emails) => {
    const response = await apiClient.post(`/transcripts/${id}/share`, { emails });
    return response.data;
  },
  
  /**
   * Search transcripts
   * @param {string} query - Search query
   * @returns {Promise<Array>} - Search results
   */
  searchTranscripts: async (query) => {
    const response = await apiClient.get('/transcripts/search', {
      params: { q: query },
    });
    return response.data;
  },
  
  /**
   * Export a transcript to a file (PDF, DOCX, etc.)
   * @param {string} id - Transcript ID
   * @param {string} format - Export format (pdf, docx, txt)
   * @returns {Promise<Blob>} - File blob
   */
  exportTranscript: async (id, format = 'pdf') => {
    const response = await apiClient.get(`/transcripts/${id}/export`, {
      params: { format },
      responseType: 'blob',
    });
    return response.data;
  },
  
  /**
   * Get transcript with timestamps for synchronized playback
   * @param {string} id - Transcript ID
   * @returns {Promise<Object>} - Transcript with timestamps
   */
  getTranscriptWithTimestamps: async (id) => {
    const response = await apiClient.get(`/transcripts/${id}/timestamps`);
    return response.data;
  },
};

export default transcriptService;
