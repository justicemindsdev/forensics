import { 
  getApiSources, 
  fetchFromSource, 
  fetchFromAllSources, 
  getSourceNames, 
  sourceExists, 
  getSourceUrl 
} from './apiGrainUtils';

/**
 * Example usage of the API Grain utilities
 * This file demonstrates how to use the apiGrainUtils functions
 * to work with API sources defined in the apigrain directory.
 */

// Example function to demonstrate getting all API sources
async function demonstrateApiGrain() {
  console.log('=== API Grain Demonstration ===');
  
  // Get all API sources
  const sources = getApiSources();
  console.log('Available API sources:', sources);
  
  // Get list of source names
  const sourceNames = getSourceNames();
  console.log('Source names:', sourceNames);
  
  // Check if a source exists
  if (sourceNames.length > 0) {
    const firstSource = sourceNames[0];
    console.log(`Does '${firstSource}' exist?`, sourceExists(firstSource));
    console.log(`URL for '${firstSource}':`, getSourceUrl(firstSource));
    
    // Fetch data from a specific source
    try {
      console.log(`Fetching data from '${firstSource}'...`);
      // Note: In a real application, you would handle this data appropriately
      // This is just a demonstration of the API
      const data = await fetchFromSource(firstSource);
      console.log(`Data from '${firstSource}':`, data);
    } catch (error) {
      console.error(`Error fetching from '${firstSource}':`, error);
    }
  }
}

// Example of how to use the API Grain utilities in a Next.js API route
export async function getApiData() {
  try {
    // Get all available sources
    const sourceNames = getSourceNames();
    
    if (sourceNames.length === 0) {
      return { error: 'No API sources found' };
    }
    
    // For this example, we'll use the first source
    const sourceName = sourceNames[0];
    
    // Check if the source exists
    if (!sourceExists(sourceName)) {
      return { error: `Source '${sourceName}' not found` };
    }
    
    // Get the URL for the source
    const url = getSourceUrl(sourceName);
    
    // Fetch data from the source
    const data = await fetchFromSource(sourceName);
    
    return {
      source: sourceName,
      url,
      data
    };
  } catch (error) {
    return { 
      error: true, 
      message: (error as Error).message 
    };
  }
}

// In a real application, you would call these functions from your components or API routes
// For demonstration purposes, you could run this file directly with:
// ts-node example.ts
if (require.main === module) {
  demonstrateApiGrain().catch(console.error);
}
