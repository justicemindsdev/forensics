const crypto = require('crypto');
const { ApiError } = require('./errorHandler');
const logger = require('../utils/logger');

/**
 * Validates Zoom webhook requests
 * Verifies the request signature using the Zoom verification token
 */
const validateZoomWebhook = (req, res, next) => {
  try {
    // Get Zoom verification token from environment variables
    const zoomVerificationToken = process.env.ZOOM_VERIFICATION_TOKEN;
    
    if (!zoomVerificationToken) {
      logger.error('ZOOM_VERIFICATION_TOKEN is not set in environment variables');
      throw new ApiError(500, 'Server configuration error');
    }
    
    // Get headers from the request
    const signature = req.headers['x-zm-signature'];
    const timestamp = req.headers['x-zm-request-timestamp'];
    
    if (!signature || !timestamp) {
      logger.warn('Missing Zoom webhook signature or timestamp headers');
      throw new ApiError(401, 'Invalid webhook request');
    }
    
    // Get request body as string
    const requestBody = JSON.stringify(req.body);
    
    // Construct message to hash
    const message = `v0:${timestamp}:${requestBody}`;
    
    // Create hash
    const hashForVerify = crypto
      .createHmac('sha256', zoomVerificationToken)
      .update(message)
      .digest('hex');
    
    // Construct expected signature
    const expectedSignature = `v0=${hashForVerify}`;
    
    // Verify signature
    if (signature !== expectedSignature) {
      logger.warn('Invalid Zoom webhook signature');
      throw new ApiError(401, 'Invalid webhook signature');
    }
    
    // If signature is valid, proceed
    next();
  } catch (error) {
    next(error);
  }
};

module.exports = {
  validateZoomWebhook
};
