const { OpenAI } = require('openai');
const fs = require('fs');
const path = require('path');
const { promisify } = require('util');
const { ApiError } = require('../middleware/errorHandler');
const logger = require('../utils/logger');
const { getMinioClient } = require('./minio');
const { publishToQueue } = require('./rabbitmq');
const { getRedisClient } = require('./redis');

// Promisify fs functions
const writeFile = promisify(fs.writeFile);
const unlink = promisify(fs.unlink);
const mkdir = promisify(fs.mkdir);

// Create temp directory if it doesn't exist
const tempDir = path.join(__dirname, '../../temp');
if (!fs.existsSync(tempDir)) {
  fs.mkdirSync(tempDir, { recursive: true });
}

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

/**
 * Transcription service
 */
class TranscriptionService {
  /**
   * Create a new transcription job
   * @param {string} recordingId - ID of the recording to transcribe
   * @param {Object} options - Transcription options
   * @param {string} options.language - Language code (e.g., 'en', 'fr')
   * @param {string} options.model - Whisper model to use (e.g., 'whisper-1')
   * @param {string} userId - ID of the user who initiated the transcription
   * @returns {Promise<Object>} - Transcription job data
   */
  static async createTranscriptionJob(recordingId, options = {}, userId) {
    try {
      // Default options
      const transcriptionOptions = {
        language: options.language || 'en',
        model: options.model || 'whisper-1',
        responseFormat: 'verbose_json',
        temperature: 0,
        ...options,
      };

      // Create job data
      const jobId = `transcription_${recordingId}_${Date.now()}`;
      const jobData = {
        id: jobId,
        recordingId,
        userId,
        status: 'pending',
        options: transcriptionOptions,
        createdAt: new Date().toISOString(),
      };

      // Store job data in Redis
      const redisClient = await getRedisClient();
      await redisClient.set(`job:${jobId}`, JSON.stringify(jobData));
      await redisClient.set(`recording:${recordingId}:transcription`, jobId);

      // Publish job to RabbitMQ queue
      await publishToQueue('transcription', jobData);

      logger.info(`Created transcription job ${jobId} for recording ${recordingId}`);
      return jobData;
    } catch (error) {
      logger.error('Error creating transcription job:', error);
      throw new ApiError(500, 'Failed to create transcription job');
    }
  }

  /**
   * Get transcription job status
   * @param {string} recordingId - ID of the recording
   * @returns {Promise<Object>} - Transcription job status
   */
  static async getTranscriptionStatus(recordingId) {
    try {
      const redisClient = await getRedisClient();
      
      // Get job ID for recording
      const jobId = await redisClient.get(`recording:${recordingId}:transcription`);
      
      if (!jobId) {
        return { status: 'not_found' };
      }
      
      // Get job data
      const jobData = await redisClient.get(`job:${jobId}`);
      
      if (!jobData) {
        return { status: 'not_found' };
      }
      
      return JSON.parse(jobData);
    } catch (error) {
      logger.error('Error getting transcription status:', error);
      throw new ApiError(500, 'Failed to get transcription status');
    }
  }

  /**
   * Process transcription job
   * @param {Object} jobData - Transcription job data
   * @returns {Promise<Object>} - Processed transcription data
   */
  static async processTranscriptionJob(jobData) {
    const { id: jobId, recordingId, options } = jobData;
    let tempFilePath = null;
    
    try {
      logger.info(`Processing transcription job ${jobId} for recording ${recordingId}`);
      
      // Update job status
      await this.updateJobStatus(jobId, 'processing');
      
      // Get MinIO client
      const minioClient = await getMinioClient();
      
      // Get recording file from MinIO
      const bucketName = process.env.MINIO_BUCKET || 'justice-minds';
      const objectName = `recordings/${recordingId}`;
      
      // Create temp file path
      tempFilePath = path.join(tempDir, `${recordingId}_${Date.now()}.mp3`);
      
      // Download file from MinIO
      await minioClient.fGetObject(bucketName, objectName, tempFilePath);
      
      // Transcribe audio using OpenAI Whisper
      const transcription = await this.transcribeAudio(tempFilePath, options);
      
      // Process and store transcription
      const processedTranscription = await this.processAndStoreTranscription(recordingId, transcription);
      
      // Update job status
      await this.updateJobStatus(jobId, 'completed', { transcriptId: processedTranscription.id });
      
      // Clean up temp file
      if (tempFilePath && fs.existsSync(tempFilePath)) {
        await unlink(tempFilePath);
      }
      
      return processedTranscription;
    } catch (error) {
      logger.error(`Error processing transcription job ${jobId}:`, error);
      
      // Update job status to failed
      await this.updateJobStatus(jobId, 'failed', { error: error.message });
      
      // Clean up temp file
      if (tempFilePath && fs.existsSync(tempFilePath)) {
        await unlink(tempFilePath);
      }
      
      throw error;
    }
  }

  /**
   * Transcribe audio using OpenAI Whisper
   * @param {string} filePath - Path to audio file
   * @param {Object} options - Transcription options
   * @returns {Promise<Object>} - Transcription data
   */
  static async transcribeAudio(filePath, options) {
    try {
      logger.info(`Transcribing audio file: ${filePath}`);
      
      const transcription = await openai.audio.transcriptions.create({
        file: fs.createReadStream(filePath),
        model: options.model,
        language: options.language,
        response_format: options.responseFormat,
        temperature: options.temperature,
      });
      
      return transcription;
    } catch (error) {
      logger.error('Error transcribing audio:', error);
      throw new ApiError(500, 'Failed to transcribe audio');
    }
  }

  /**
   * Process and store transcription
   * @param {string} recordingId - ID of the recording
   * @param {Object} transcription - Raw transcription data from OpenAI
   * @returns {Promise<Object>} - Processed transcription data
   */
  static async processAndStoreTranscription(recordingId, transcription) {
    try {
      // Generate a unique ID for the transcript
      const transcriptId = `transcript_${recordingId}_${Date.now()}`;
      
      // Process segments with timestamps
      const segments = transcription.segments.map(segment => ({
        id: segment.id,
        start: segment.start,
        end: segment.end,
        text: segment.text,
        confidence: segment.confidence,
      }));
      
      // Create transcript data
      const transcriptData = {
        id: transcriptId,
        recordingId,
        text: transcription.text,
        segments,
        language: transcription.language,
        duration: transcription.duration,
        createdAt: new Date().toISOString(),
      };
      
      // Store transcript in MinIO
      const minioClient = await getMinioClient();
      const bucketName = process.env.MINIO_BUCKET || 'justice-minds';
      const objectName = `transcripts/${transcriptId}.json`;
      
      // Convert transcript data to JSON string
      const transcriptJson = JSON.stringify(transcriptData, null, 2);
      
      // Create temp file for transcript
      const tempFilePath = path.join(tempDir, `${transcriptId}.json`);
      await writeFile(tempFilePath, transcriptJson);
      
      // Upload transcript to MinIO
      await minioClient.fPutObject(bucketName, objectName, tempFilePath);
      
      // Clean up temp file
      await unlink(tempFilePath);
      
      // Store transcript metadata in Redis
      const redisClient = await getRedisClient();
      await redisClient.set(`transcript:${transcriptId}`, JSON.stringify({
        id: transcriptId,
        recordingId,
        language: transcription.language,
        duration: transcription.duration,
        createdAt: transcriptData.createdAt,
      }));
      
      // Add transcript ID to recording's transcripts list
      await redisClient.sAdd(`recording:${recordingId}:transcripts`, transcriptId);
      
      logger.info(`Stored transcript ${transcriptId} for recording ${recordingId}`);
      
      return transcriptData;
    } catch (error) {
      logger.error('Error processing and storing transcription:', error);
      throw new ApiError(500, 'Failed to process and store transcription');
    }
  }

  /**
   * Update job status
   * @param {string} jobId - ID of the job
   * @param {string} status - New status
   * @param {Object} data - Additional data to store
   * @returns {Promise<void>}
   */
  static async updateJobStatus(jobId, status, data = {}) {
    try {
      const redisClient = await getRedisClient();
      
      // Get current job data
      const jobDataStr = await redisClient.get(`job:${jobId}`);
      
      if (!jobDataStr) {
        throw new Error(`Job ${jobId} not found`);
      }
      
      const jobData = JSON.parse(jobDataStr);
      
      // Update job data
      const updatedJobData = {
        ...jobData,
        status,
        ...data,
        updatedAt: new Date().toISOString(),
      };
      
      // Store updated job data
      await redisClient.set(`job:${jobId}`, JSON.stringify(updatedJobData));
      
      logger.info(`Updated job ${jobId} status to ${status}`);
    } catch (error) {
      logger.error(`Error updating job ${jobId} status:`, error);
      throw error;
    }
  }

  /**
   * Get transcript by ID
   * @param {string} transcriptId - ID of the transcript
   * @returns {Promise<Object>} - Transcript data
   */
  static async getTranscriptById(transcriptId) {
    try {
      // Get MinIO client
      const minioClient = await getMinioClient();
      const bucketName = process.env.MINIO_BUCKET || 'justice-minds';
      const objectName = `transcripts/${transcriptId}.json`;
      
      // Create temp file path
      const tempFilePath = path.join(tempDir, `${transcriptId}_${Date.now()}.json`);
      
      // Download file from MinIO
      await minioClient.fGetObject(bucketName, objectName, tempFilePath);
      
      // Read transcript data
      const transcriptData = JSON.parse(fs.readFileSync(tempFilePath, 'utf8'));
      
      // Clean up temp file
      await unlink(tempFilePath);
      
      return transcriptData;
    } catch (error) {
      logger.error(`Error getting transcript ${transcriptId}:`, error);
      throw new ApiError(404, 'Transcript not found');
    }
  }

  /**
   * Generate insights from transcript
   * @param {string} transcriptId - ID of the transcript
   * @returns {Promise<Object>} - Insights data
   */
  static async generateInsights(transcriptId) {
    try {
      // Get transcript data
      const transcript = await this.getTranscriptById(transcriptId);
      
      // Use OpenAI to generate insights
      const completion = await openai.chat.completions.create({
        model: 'gpt-4',
        messages: [
          {
            role: 'system',
            content: 'You are an AI assistant that analyzes meeting transcripts and extracts key insights, action items, and summaries.'
          },
          {
            role: 'user',
            content: `Please analyze this transcript and provide insights:\n\n${transcript.text}`
          }
        ],
        functions: [
          {
            name: 'generate_transcript_insights',
            description: 'Generate insights from a meeting transcript',
            parameters: {
              type: 'object',
              properties: {
                summary: {
                  type: 'string',
                  description: 'A concise summary of the meeting'
                },
                key_points: {
                  type: 'array',
                  items: {
                    type: 'string'
                  },
                  description: 'Key points discussed in the meeting'
                },
                action_items: {
                  type: 'array',
                  items: {
                    type: 'object',
                    properties: {
                      task: {
                        type: 'string',
                        description: 'The action item task'
                      },
                      assignee: {
                        type: 'string',
                        description: 'The person assigned to the task, if mentioned'
                      },
                      due_date: {
                        type: 'string',
                        description: 'The due date for the task, if mentioned'
                      }
                    },
                    required: ['task']
                  },
                  description: 'Action items identified in the meeting'
                },
                sentiment: {
                  type: 'string',
                  enum: ['positive', 'neutral', 'negative', 'mixed'],
                  description: 'Overall sentiment of the meeting'
                },
                topics: {
                  type: 'array',
                  items: {
                    type: 'string'
                  },
                  description: 'Main topics discussed in the meeting'
                }
              },
              required: ['summary', 'key_points', 'action_items', 'sentiment', 'topics']
            }
          }
        ],
        function_call: { name: 'generate_transcript_insights' }
      });
      
      // Parse insights
      const insights = JSON.parse(completion.choices[0].message.function_call.arguments);
      
      // Store insights in MinIO
      const minioClient = await getMinioClient();
      const bucketName = process.env.MINIO_BUCKET || 'justice-minds';
      const objectName = `insights/${transcriptId}.json`;
      
      // Convert insights to JSON string
      const insightsJson = JSON.stringify({
        transcriptId,
        ...insights,
        createdAt: new Date().toISOString()
      }, null, 2);
      
      // Create temp file for insights
      const tempFilePath = path.join(tempDir, `insights_${transcriptId}_${Date.now()}.json`);
      await writeFile(tempFilePath, insightsJson);
      
      // Upload insights to MinIO
      await minioClient.fPutObject(bucketName, objectName, tempFilePath);
      
      // Clean up temp file
      await unlink(tempFilePath);
      
      logger.info(`Generated insights for transcript ${transcriptId}`);
      
      return insights;
    } catch (error) {
      logger.error(`Error generating insights for transcript ${transcriptId}:`, error);
      throw new ApiError(500, 'Failed to generate insights');
    }
  }
}

module.exports = TranscriptionService;
