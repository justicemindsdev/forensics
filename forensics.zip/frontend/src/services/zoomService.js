import apiClient from './apiClient';

/**
 * Zoom service for handling Zoom integration
 * Note: This is a placeholder service with minimal implementation
 * Full integration will be implemented in a later phase
 */
const zoomService = {
  /**
   * Get Zoom integration status
   * @returns {Promise<Object>} - Zoom status
   */
  getZoomStatus: async () => {
    const response = await apiClient.get('/integrations/zoom/status');
    return response.data;
  },
  
  /**
   * Authenticate with Zoom using OAuth
   * @param {string} code - OAuth authorization code
   * @returns {Promise<Object>} - Authentication result
   */
  authenticateZoom: async (code) => {
    const response = await apiClient.post('/integrations/zoom/auth', { code });
    return response.data;
  },
  
  /**
   * Disconnect Zoom integration
   * @returns {Promise<void>}
   */
  disconnectZoom: async () => {
    await apiClient.delete('/integrations/zoom/disconnect');
  },
  
  /**
   * Get Zoom recordings
   * @returns {Promise<Array>} - List of Zoom recordings
   */
  getZoomRecordings: async () => {
    const response = await apiClient.get('/integrations/zoom/recordings');
    return response.data;
  },
  
  /**
   * Import a Zoom recording
   * @param {string} meetingId - Zoom meeting ID
   * @param {string} title - Recording title (optional)
   * @param {string} description - Recording description (optional)
   * @returns {Promise<Object>} - Imported recording data
   */
  importZoomRecording: async (meetingId, title = '', description = '') => {
    const response = await apiClient.post(`/integrations/zoom/recordings/${meetingId}/import`, {
      title,
      description,
    });
    return response.data;
  },
};

export default zoomService;
