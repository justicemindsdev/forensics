#!/usr/bin/env node
require('dotenv').config();
const { startWorker } = require('../workers/transcriptionWorker');
const logger = require('../utils/logger');

/**
 * Start the transcription worker
 */
async function main() {
  try {
    logger.info('Starting transcription worker script...');
    await startWorker();
    logger.info('Transcription worker started successfully');
    
    // Keep the process running
    process.on('SIGINT', () => {
      logger.info('Shutting down transcription worker...');
      process.exit(0);
    });
  } catch (error) {
    logger.error('Failed to start transcription worker:', error);
    process.exit(1);
  }
}

// Run the main function
main();
