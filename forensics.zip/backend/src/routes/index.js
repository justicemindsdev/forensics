const express = require('express');
const authRoutes = require('./auth.routes');
const userRoutes = require('./user.routes');
const recordingRoutes = require('./recording.routes');
const transcriptRoutes = require('./transcript.routes');
const zoomRoutes = require('./zoom.routes');
const googleDriveRoutes = require('./googleDrive.routes');

const router = express.Router();

// Health check route
router.get('/health', (req, res) => {
  res.status(200).json({ status: 'ok' });
});

// API routes
router.use('/auth', authRoutes);
router.use('/users', userRoutes);
router.use('/recordings', recordingRoutes);
router.use('/transcripts', transcriptRoutes);
router.use('/integrations/zoom', zoomRoutes);
router.use('/integrations/google-drive', googleDriveRoutes);

module.exports = router;
