const { v4: uuidv4 } = require('uuid');
const { ApiError } = require('../middleware/errorHandler');
const logger = require('../utils/logger');
const { getMinioClient } = require('../services/minio');
const { getRedisClient } = require('../services/redis');
const TranscriptionService = require('../services/transcription');

/**
 * Recording controller
 */
const recordingController = {
  /**
   * Upload a new recording
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   * @param {Function} next - Express next function
   */
  uploadRecording: async (req, res, next) => {
    try {
      // Check if file was uploaded
      if (!req.file) {
        throw ApiError.badRequest('No file uploaded');
      }

      // Generate a unique ID for the recording
      const recordingId = uuidv4();
      
      // Get file details
      const { originalname, mimetype, size, path: tempPath } = req.file;
      const { title, description } = req.body;
      
      // Upload file to MinIO
      const minioClient = await getMinioClient();
      const bucketName = process.env.MINIO_BUCKET || 'justice-minds';
      const objectName = `recordings/${recordingId}`;
      
      // Ensure bucket exists
      const bucketExists = await minioClient.bucketExists(bucketName);
      if (!bucketExists) {
        await minioClient.makeBucket(bucketName);
      }
      
      // Upload file
      await minioClient.fPutObject(bucketName, objectName, tempPath, {
        'Content-Type': mimetype,
        'X-Amz-Meta-Original-Filename': originalname,
      });
      
      // Create recording metadata
      const recordingData = {
        id: recordingId,
        userId: req.user.id,
        title,
        description,
        filename: originalname,
        mimetype,
        size,
        createdAt: new Date().toISOString(),
      };
      
      // Store recording metadata in Redis
      const redisClient = await getRedisClient();
      await redisClient.set(`recording:${recordingId}`, JSON.stringify(recordingData));
      
      // Add recording to user's recordings list
      await redisClient.sAdd(`user:${req.user.id}:recordings`, recordingId);
      
      logger.info(`User ${req.user.id} uploaded recording ${recordingId}`);
      
      // Return success response
      res.status(201).json({
        status: 'success',
        data: recordingData,
      });
    } catch (error) {
      next(error);
    }
  },

  /**
   * Get all recordings for the current user
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   * @param {Function} next - Express next function
   */
  getRecordings: async (req, res, next) => {
    try {
      const redisClient = await getRedisClient();
      
      // Get recording IDs for user
      const recordingIds = await redisClient.sMembers(`user:${req.user.id}:recordings`);
      
      if (!recordingIds || recordingIds.length === 0) {
        return res.status(200).json({
          status: 'success',
          data: [],
        });
      }
      
      // Get recording data for each ID
      const recordings = [];
      
      for (const recordingId of recordingIds) {
        const recordingData = await redisClient.get(`recording:${recordingId}`);
        
        if (recordingData) {
          recordings.push(JSON.parse(recordingData));
        }
      }
      
      // Sort recordings by creation date (newest first)
      recordings.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
      
      res.status(200).json({
        status: 'success',
        data: recordings,
      });
    } catch (error) {
      next(error);
    }
  },

  /**
   * Get a recording by ID
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   * @param {Function} next - Express next function
   */
  getRecordingById: async (req, res, next) => {
    try {
      const { id } = req.params;
      const redisClient = await getRedisClient();
      
      // Get recording data
      const recordingData = await redisClient.get(`recording:${id}`);
      
      if (!recordingData) {
        throw ApiError.notFound('Recording not found');
      }
      
      const recording = JSON.parse(recordingData);
      
      // Check if user has access to this recording
      if (recording.userId !== req.user.id) {
        throw ApiError.forbidden('You do not have access to this recording');
      }
      
      // Get transcription status if available
      const transcriptionStatus = await TranscriptionService.getTranscriptionStatus(id);
      
      // Add transcription status to response
      if (transcriptionStatus && transcriptionStatus.status !== 'not_found') {
        recording.transcription = {
          status: transcriptionStatus.status,
          updatedAt: transcriptionStatus.updatedAt,
        };
        
        if (transcriptionStatus.transcriptId) {
          recording.transcription.transcriptId = transcriptionStatus.transcriptId;
        }
      }
      
      res.status(200).json({
        status: 'success',
        data: recording,
      });
    } catch (error) {
      next(error);
    }
  },

  /**
   * Update a recording
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   * @param {Function} next - Express next function
   */
  updateRecording: async (req, res, next) => {
    try {
      const { id } = req.params;
      const { title, description } = req.body;
      const redisClient = await getRedisClient();
      
      // Get recording data
      const recordingData = await redisClient.get(`recording:${id}`);
      
      if (!recordingData) {
        throw ApiError.notFound('Recording not found');
      }
      
      const recording = JSON.parse(recordingData);
      
      // Check if user has access to this recording
      if (recording.userId !== req.user.id) {
        throw ApiError.forbidden('You do not have access to this recording');
      }
      
      // Update recording data
      if (title !== undefined) {
        recording.title = title;
      }
      
      if (description !== undefined) {
        recording.description = description;
      }
      
      recording.updatedAt = new Date().toISOString();
      
      // Store updated recording data
      await redisClient.set(`recording:${id}`, JSON.stringify(recording));
      
      logger.info(`User ${req.user.id} updated recording ${id}`);
      
      res.status(200).json({
        status: 'success',
        data: recording,
      });
    } catch (error) {
      next(error);
    }
  },

  /**
   * Delete a recording
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   * @param {Function} next - Express next function
   */
  deleteRecording: async (req, res, next) => {
    try {
      const { id } = req.params;
      const redisClient = await getRedisClient();
      
      // Get recording data
      const recordingData = await redisClient.get(`recording:${id}`);
      
      if (!recordingData) {
        throw ApiError.notFound('Recording not found');
      }
      
      const recording = JSON.parse(recordingData);
      
      // Check if user has access to this recording
      if (recording.userId !== req.user.id) {
        throw ApiError.forbidden('You do not have access to this recording');
      }
      
      // Delete recording file from MinIO
      const minioClient = await getMinioClient();
      const bucketName = process.env.MINIO_BUCKET || 'justice-minds';
      const objectName = `recordings/${id}`;
      
      await minioClient.removeObject(bucketName, objectName);
      
      // Delete recording metadata from Redis
      await redisClient.del(`recording:${id}`);
      
      // Remove recording from user's recordings list
      await redisClient.sRem(`user:${req.user.id}:recordings`, id);
      
      // Delete any associated transcriptions
      const transcriptIds = await redisClient.sMembers(`recording:${id}:transcripts`);
      
      if (transcriptIds && transcriptIds.length > 0) {
        for (const transcriptId of transcriptIds) {
          // Delete transcript file from MinIO
          await minioClient.removeObject(bucketName, `transcripts/${transcriptId}.json`);
          
          // Delete transcript metadata from Redis
          await redisClient.del(`transcript:${transcriptId}`);
          
          // Delete any insights
          await minioClient.removeObject(bucketName, `insights/${transcriptId}.json`);
        }
        
        // Delete transcripts list
        await redisClient.del(`recording:${id}:transcripts`);
      }
      
      // Delete transcription job if exists
      const jobId = await redisClient.get(`recording:${id}:transcription`);
      
      if (jobId) {
        await redisClient.del(`job:${jobId}`);
        await redisClient.del(`recording:${id}:transcription`);
      }
      
      logger.info(`User ${req.user.id} deleted recording ${id}`);
      
      res.status(200).json({
        status: 'success',
        message: 'Recording deleted successfully',
      });
    } catch (error) {
      next(error);
    }
  },

  /**
   * Transcribe a recording
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   * @param {Function} next - Express next function
   */
  transcribeRecording: async (req, res, next) => {
    try {
      const { id } = req.params;
      const { language, model, generateInsights = true } = req.body;
      const redisClient = await getRedisClient();
      
      // Get recording data
      const recordingData = await redisClient.get(`recording:${id}`);
      
      if (!recordingData) {
        throw ApiError.notFound('Recording not found');
      }
      
      const recording = JSON.parse(recordingData);
      
      // Check if user has access to this recording
      if (recording.userId !== req.user.id) {
        throw ApiError.forbidden('You do not have access to this recording');
      }
      
      // Check if recording is already being transcribed
      const existingJobId = await redisClient.get(`recording:${id}:transcription`);
      
      if (existingJobId) {
        const jobData = await redisClient.get(`job:${existingJobId}`);
        
        if (jobData) {
          const job = JSON.parse(jobData);
          
          if (['pending', 'processing'].includes(job.status)) {
            throw ApiError.conflict('Recording is already being transcribed');
          }
        }
      }
      
      // Create transcription job
      const options = {
        language,
        model,
        generateInsights,
      };
      
      const jobData = await TranscriptionService.createTranscriptionJob(id, options, req.user.id);
      
      logger.info(`User ${req.user.id} requested transcription for recording ${id}`);
      
      res.status(202).json({
        status: 'success',
        message: 'Transcription job created successfully',
        data: {
          jobId: jobData.id,
          status: jobData.status,
          createdAt: jobData.createdAt,
        },
      });
    } catch (error) {
      next(error);
    }
  },

  /**
   * Get transcription status
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   * @param {Function} next - Express next function
   */
  getTranscriptionStatus: async (req, res, next) => {
    try {
      const { id } = req.params;
      const redisClient = await getRedisClient();
      
      // Get recording data
      const recordingData = await redisClient.get(`recording:${id}`);
      
      if (!recordingData) {
        throw ApiError.notFound('Recording not found');
      }
      
      const recording = JSON.parse(recordingData);
      
      // Check if user has access to this recording
      if (recording.userId !== req.user.id) {
        throw ApiError.forbidden('You do not have access to this recording');
      }
      
      // Get transcription status
      const status = await TranscriptionService.getTranscriptionStatus(id);
      
      res.status(200).json({
        status: 'success',
        data: status,
      });
    } catch (error) {
      next(error);
    }
  },

  /**
   * Get a presigned URL for a recording file
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   * @param {Function} next - Express next function
   */
  getRecordingUrl: async (req, res, next) => {
    try {
      const { id } = req.params;
      const redisClient = await getRedisClient();
      
      // Get recording data
      const recordingData = await redisClient.get(`recording:${id}`);
      
      if (!recordingData) {
        throw ApiError.notFound('Recording not found');
      }
      
      const recording = JSON.parse(recordingData);
      
      // Check if user has access to this recording
      if (recording.userId !== req.user.id) {
        throw ApiError.forbidden('You do not have access to this recording');
      }
      
      // Generate presigned URL
      const minioClient = await getMinioClient();
      const bucketName = process.env.MINIO_BUCKET || 'justice-minds';
      const objectName = `recordings/${id}`;
      
      // URL expires in 1 hour
      const url = await minioClient.presignedGetObject(bucketName, objectName, 60 * 60);
      
      res.status(200).json({
        status: 'success',
        data: {
          url,
          expiresIn: 60 * 60, // 1 hour in seconds
        },
      });
    } catch (error) {
      next(error);
    }
  },
};

module.exports = recordingController;
