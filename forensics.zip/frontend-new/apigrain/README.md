# API Grain System with Grain API Integration

This system allows you to use external API endpoints as data sources by simply adding files to the `frontend-new/apigrain` directory. It includes special handling for the Grain API.

## How It Works

1. Each file in the `apigrain` directory contains a URL to an API endpoint.
2. The filename is used as the identifier for the API source.
3. The system provides utilities to fetch data from these sources.
4. Special handling is provided for the Grain API (grain.com).

## Current Sources

- `grain.com` - Grain Public API (https://grainhq.notion.site/Grain-Public-API-877184aa82b54c77a875083c1b560de9)

## Configuration

### Environment Variables

For the Grain API integration, you need to set the following environment variable:

```
GRAIN_API_TOKEN=your_grain_api_token
```

This can be done in a `.env.local` file in the `frontend-new` directory.

## Adding a New API Source

To add a new API source, create a file in the `frontend-new/apigrain` directory. The filename will be used as the identifier for the API source, and the file should contain the URL to the API endpoint.

```bash
# Example: Adding a new API source
echo "https://api.example.com/data" > frontend-new/apigrain/example-api.com
```

## Using API Grain in Your Code

### Utility Functions

The `apiGrainUtils.ts` file provides several utility functions for working with API sources:

```typescript
// Import the API Grain utilities
import { 
  getApiSources, 
  fetchFromSource, 
  fetchFromAllSources, 
  getSourceNames, 
  sourceExists, 
  getSourceUrl 
} from './apiGrainUtils';

// Get all API sources
const sources = getApiSources();
console.log('Available API sources:', sources);

// Get list of source names
const sourceNames = getSourceNames();
console.log('Source names:', sourceNames);

// Check if a source exists
const exists = sourceExists('grain.com');
console.log('Does grain.com exist?', exists);

// Get the URL for a source
const url = getSourceUrl('grain.com');
console.log('URL for grain.com:', url);

// Fetch data from a specific source
async function fetchData() {
  try {
    // For regular API sources
    const data = await fetchFromSource('example-api.com');
    console.log('Data:', data);
    
    // For Grain API with options
    const grainData = await fetchFromSource('grain.com', {
      endpoint: 'me' // Get current user info
    });
    console.log('Grain user data:', grainData);
    
    // Get recordings from Grain API
    const recordings = await fetchFromSource('grain.com', {
      include_highlights: true,
      include_participants: true
    });
    console.log('Grain recordings:', recordings);
    
    // Get a specific recording from Grain API
    const recording = await fetchFromSource('grain.com', {
      recordingId: 'recording-id-here',
      include_highlights: true
    });
    console.log('Grain recording:', recording);
  } catch (error) {
    console.error('Error:', error);
  }
}

// Fetch data from all sources
async function fetchAllData() {
  try {
    const data = await fetchFromAllSources();
    console.log('All sources data:', data);
  } catch (error) {
    console.error('Error:', error);
  }
}
```

### Grain API Client

For direct access to the Grain API, you can use the `grainApiClient.ts` file:

```typescript
import * as grainApi from './grainApiClient';

// Get current user info
const user = await grainApi.getCurrentUser();

// Get recordings
const recordings = await grainApi.getRecordings({
  include_highlights: true,
  include_participants: true
});

// Get a specific recording
const recording = await grainApi.getRecording('recording-id-here', {
  include_highlights: true,
  include_participants: true
});

// Get views
const views = await grainApi.getViews();

// Get hooks
const hooks = await grainApi.getHooks();
```

### React Component

The `ApiGrainViewer` component provides a UI for displaying data from API sources:

```tsx
import ApiGrainViewer from '../components/ApiGrainViewer';

// Display data from a specific source
function MyComponent() {
  return (
    <div>
      <h1>My API Data</h1>
      <ApiGrainViewer sourceName="grain.com" />
    </div>
  );
}

// Display data from all sources
function AllSourcesComponent() {
  return (
    <div>
      <h1>All API Data</h1>
      <ApiGrainViewer showAllSources={true} />
    </div>
  );
}
```

### API Routes

The system also provides API routes for fetching data from API sources:

```typescript
// Fetch data from a specific source
fetch('/api/apigrain/grain.com')
  .then(response => response.json())
  .then(data => console.log('Data:', data))
  .catch(error => console.error('Error:', error));

// Fetch current user from Grain API
fetch('/api/apigrain/grain.com?endpoint=me')
  .then(response => response.json())
  .then(data => console.log('User data:', data))
  .catch(error => console.error('Error:', error));

// Fetch a specific recording from Grain API
fetch('/api/apigrain/grain.com?recordingId=recording-id-here&include_highlights=true')
  .then(response => response.json())
  .then(data => console.log('Recording data:', data))
  .catch(error => console.error('Error:', error));

// Fetch data from all sources
fetch('/api/apigrain/all')
  .then(response => response.json())
  .then(data => console.log('All sources data:', data))
  .catch(error => console.error('Error:', error));
```

## Demo Pages

Two demo pages are available:

1. `/api-grain-demo` - Demonstrates how to use the API Grain system with any API source
2. `/grain-api` - Dedicated page for viewing Grain API data, including recordings and their details

## Architecture

The API Grain system consists of the following components:

1. **API Source Files** - Files in the `frontend-new/apigrain` directory that contain URLs to API endpoints.
2. **Utility Functions** - Functions in `apiGrainUtils.ts` for working with API sources.
3. **Grain API Client** - Dedicated client in `grainApiClient.ts` for interacting with the Grain API.
4. **React Component** - The `ApiGrainViewer` component for displaying data from API sources.
5. **API Routes** - Next.js API routes for fetching data from API sources.
6. **Demo Pages** - Pages for demonstrating the API Grain system and Grain API integration.

## Benefits

- **Simple Integration** - Add new API sources by simply creating a file with a URL.
- **Consistent Access** - Access all API sources through a unified interface.
- **Flexible Usage** - Use the system through utility functions, React components, or API routes.
- **Error Handling** - Built-in error handling for API requests.
- **Grain API Integration** - Special handling for the Grain API with support for all endpoints.
