const express = require('express');
const { body, param } = require('express-validator');
const userController = require('../controllers/user.controller');
const { validateRequest } = require('../middleware/validateRequest');
const { authenticate } = require('../middleware/authenticate');
const { authorize } = require('../middleware/authorize');

const router = express.Router();

// Apply authentication middleware to all routes
router.use(authenticate);

/**
 * @route GET /api/users
 * @desc Get all users (admin only)
 * @access Private/Admin
 */
router.get('/', authorize('admin'), userController.getUsers);

/**
 * @route GET /api/users/profile
 * @desc Get current user's profile
 * @access Private
 */
router.get('/profile', userController.getUserProfile);

/**
 * @route PUT /api/users/profile
 * @desc Update current user's profile
 * @access Private
 */
router.put(
  '/profile',
  [
    body('name').optional(),
    body('email').optional().isEmail().withMessage('Please provide a valid email'),
    validateRequest
  ],
  userController.updateUserProfile
);

/**
 * @route PUT /api/users/password
 * @desc Update current user's password
 * @access Private
 */
router.put(
  '/password',
  [
    body('currentPassword').not().isEmpty().withMessage('Current password is required'),
    body('newPassword')
      .isLength({ min: 8 })
      .withMessage('New password must be at least 8 characters long'),
    validateRequest
  ],
  userController.updatePassword
);

/**
 * @route GET /api/users/:id
 * @desc Get user by ID (admin only)
 * @access Private/Admin
 */
router.get(
  '/:id',
  [
    param('id').isUUID().withMessage('Invalid user ID'),
    validateRequest
  ],
  authorize('admin'),
  userController.getUserById
);

/**
 * @route PUT /api/users/:id
 * @desc Update user by ID (admin only)
 * @access Private/Admin
 */
router.put(
  '/:id',
  [
    param('id').isUUID().withMessage('Invalid user ID'),
    body('name').optional(),
    body('email').optional().isEmail().withMessage('Please provide a valid email'),
    body('role').optional().isIn(['user', 'admin']).withMessage('Invalid role'),
    validateRequest
  ],
  authorize('admin'),
  userController.updateUser
);

/**
 * @route DELETE /api/users/:id
 * @desc Delete user by ID (admin only)
 * @access Private/Admin
 */
router.delete(
  '/:id',
  [
    param('id').isUUID().withMessage('Invalid user ID'),
    validateRequest
  ],
  authorize('admin'),
  userController.deleteUser
);

/**
 * @route GET /api/users/:id/recordings
 * @desc Get all recordings for a user (admin only)
 * @access Private/Admin
 */
router.get(
  '/:id/recordings',
  [
    param('id').isUUID().withMessage('Invalid user ID'),
    validateRequest
  ],
  authorize('admin'),
  userController.getUserRecordings
);

/**
 * @route GET /api/users/:id/transcripts
 * @desc Get all transcripts for a user (admin only)
 * @access Private/Admin
 */
router.get(
  '/:id/transcripts',
  [
    param('id').isUUID().withMessage('Invalid user ID'),
    validateRequest
  ],
  authorize('admin'),
  userController.getUserTranscripts
);

module.exports = router;
