const express = require('express');
const { body, param } = require('express-validator');
const recordingController = require('../controllers/recording.controller');
const { validateRequest } = require('../middleware/validateRequest');
const { authenticate } = require('../middleware/authenticate');
const { uploadRateLimiter, transcriptionRateLimiter } = require('../middleware/rateLimiter');
const upload = require('../middleware/upload');

const router = express.Router();

// Apply authentication middleware to all routes
router.use(authenticate);

/**
 * @route POST /api/recordings
 * @desc Upload a new recording
 * @access Private
 */
router.post(
  '/',
  uploadRateLimiter, // Apply upload rate limiter
  upload.single('file'),
  [
    body('title')
      .not().isEmpty()
      .withMessage('Title is required')
      .trim()
      .escape(),
    body('description')
      .optional()
      .trim()
      .escape(),
    validateRequest
  ],
  recordingController.uploadRecording
);

/**
 * @route GET /api/recordings
 * @desc Get all recordings for the current user
 * @access Private
 */
router.get('/', recordingController.getRecordings);

/**
 * @route GET /api/recordings/:id
 * @desc Get a recording by ID
 * @access Private
 */
router.get(
  '/:id',
  [
    param('id').isUUID().withMessage('Invalid recording ID'),
    validateRequest
  ],
  recordingController.getRecordingById
);

/**
 * @route PUT /api/recordings/:id
 * @desc Update a recording
 * @access Private
 */
router.put(
  '/:id',
  [
    param('id').isUUID().withMessage('Invalid recording ID'),
    body('title')
      .optional()
      .trim()
      .escape(),
    body('description')
      .optional()
      .trim()
      .escape(),
    validateRequest
  ],
  recordingController.updateRecording
);

/**
 * @route DELETE /api/recordings/:id
 * @desc Delete a recording
 * @access Private
 */
router.delete(
  '/:id',
  [
    param('id').isUUID().withMessage('Invalid recording ID'),
    validateRequest
  ],
  recordingController.deleteRecording
);

/**
 * @route POST /api/recordings/:id/transcribe
 * @desc Transcribe a recording
 * @access Private
 */
router.post(
  '/:id/transcribe',
  transcriptionRateLimiter, // Apply transcription rate limiter
  [
    param('id').isUUID().withMessage('Invalid recording ID'),
    body('language')
      .optional()
      .isString()
      .isLength({ min: 2, max: 5 })
      .withMessage('Language code must be 2-5 characters'),
    body('model')
      .optional()
      .isString()
      .withMessage('Model must be a string'),
    validateRequest
  ],
  recordingController.transcribeRecording
);

/**
 * @route GET /api/recordings/:id/status
 * @desc Get transcription status
 * @access Private
 */
router.get(
  '/:id/status',
  [
    param('id').isUUID().withMessage('Invalid recording ID'),
    validateRequest
  ],
  recordingController.getTranscriptionStatus
);

/**
 * @route GET /api/recordings/:id/url
 * @desc Get a presigned URL for a recording file
 * @access Private
 */
router.get(
  '/:id/url',
  [
    param('id').isUUID().withMessage('Invalid recording ID'),
    validateRequest
  ],
  recordingController.getRecordingUrl
);

module.exports = router;
