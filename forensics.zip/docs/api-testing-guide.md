# Justice Minds API Testing Guide

This guide explains how to test the Justice Minds Forensic Transcription service API using Postman.

## Prerequisites

- [Postman](https://www.postman.com/downloads/) installed on your machine
- Justice Minds API running locally or in a development environment

## Setup

1. Import the Postman collection and environment:
   - Open Postman
   - Click on "Import" in the top left corner
   - Select the `justice-minds-api.postman_collection.json` and `justice-minds-api.postman_environment.json` files
   - Click "Import"

2. Select the environment:
   - In the top right corner, select "Justice Minds API - Development" from the environment dropdown

3. Configure the environment variables:
   - Click on the eye icon next to the environment dropdown
   - Verify that `baseUrl` is set correctly (default: `http://localhost:3000`)
   - The other variables (`token`, `refreshToken`, `recordingId`, `transcriptId`) will be populated automatically during testing

## Authentication Flow Testing

Follow these steps to test the complete authentication flow:

1. **Register a new user**:
   - Open the "Register" request in the Authentication folder
   - Modify the request body with your test user details
   - Send the request
   - Verify that you receive a 201 Created response with user data and tokens

2. **Login**:
   - Open the "Login" request
   - Enter the email and password you used for registration
   - Send the request
   - Verify that you receive a 200 OK response with user data and tokens
   - The `token` and `refreshToken` variables will be automatically set from the response

3. **Get Current User**:
   - Open the "Get Current User" request
   - Send the request
   - Verify that you receive a 200 OK response with your user data

4. **Refresh Token**:
   - Open the "Refresh Token" request
   - Send the request
   - Verify that you receive a 200 OK response with new tokens
   - The `token` and `refreshToken` variables will be updated

5. **Logout**:
   - Open the "Logout" request
   - Send the request
   - Verify that you receive a 200 OK response

## Recording Management Testing

Follow these steps to test the recording management flow:

1. **Upload a Recording**:
   - Open the "Upload Recording" request in the Recordings folder
   - Click on the "Body" tab
   - For the "file" field, click "Select Files" and choose an audio or video file
   - Enter a title and description
   - Send the request
   - Verify that you receive a 201 Created response with recording data
   - The `recordingId` variable will be automatically set from the response

2. **Get All Recordings**:
   - Open the "Get All Recordings" request
   - Send the request
   - Verify that you receive a 200 OK response with a list of recordings

3. **Get Recording by ID**:
   - Open the "Get Recording by ID" request
   - Send the request
   - Verify that you receive a 200 OK response with the recording data

4. **Update Recording**:
   - Open the "Update Recording" request
   - Modify the request body with new title and description
   - Send the request
   - Verify that you receive a 200 OK response with updated recording data

5. **Transcribe Recording**:
   - Open the "Transcribe Recording" request
   - Send the request
   - Verify that you receive a 202 Accepted response with transcription job data

6. **Get Transcription Status**:
   - Open the "Get Transcription Status" request
   - Send the request
   - Verify that you receive a 200 OK response with transcription status
   - Note: The transcription may take some time to complete

7. **Get Recording URL**:
   - Open the "Get Recording URL" request
   - Send the request
   - Verify that you receive a 200 OK response with a presigned URL

## Transcript Management Testing

Once a recording has been transcribed, you can test the transcript management flow:

1. **Get All Transcripts**:
   - Open the "Get All Transcripts" request in the Transcripts folder
   - Send the request
   - Verify that you receive a 200 OK response with a list of transcripts
   - Find the ID of the transcript for your recording and set the `transcriptId` variable

2. **Get Transcript by ID**:
   - Open the "Get Transcript by ID" request
   - Send the request
   - Verify that you receive a 200 OK response with the transcript data

3. **Get Transcript Insights**:
   - Open the "Get Transcript Insights" request
   - Send the request
   - Verify that you receive a 200 OK response with insights data

4. **Get Transcript Action Items**:
   - Open the "Get Transcript Action Items" request
   - Send the request
   - Verify that you receive a 200 OK response with action items

5. **Get Transcript Summary**:
   - Open the "Get Transcript Summary" request
   - Send the request
   - Verify that you receive a 200 OK response with summary data

6. **Share Transcript**:
   - Open the "Share Transcript" request
   - Modify the request body with the email addresses to share with
   - Send the request
   - Verify that you receive a 200 OK response

7. **Search Transcripts**:
   - Open the "Search Transcripts" request
   - Modify the query parameter with your search term
   - Send the request
   - Verify that you receive a 200 OK response with search results

## Error Handling Testing

To test error handling, try the following:

1. **Invalid Authentication**:
   - Modify the "Login" request with incorrect credentials
   - Send the request
   - Verify that you receive a 401 Unauthorized response with an error message

2. **Invalid Input**:
   - Modify the "Register" request with an invalid email format
   - Send the request
   - Verify that you receive a 422 Unprocessable Entity response with validation errors

3. **Resource Not Found**:
   - Modify the "Get Recording by ID" request with a non-existent ID
   - Send the request
   - Verify that you receive a 404 Not Found response with an error message

4. **Rate Limiting**:
   - Send multiple "Login" requests in quick succession
   - Verify that after a certain number of requests, you receive a 429 Too Many Requests response

## Automated Testing

The Postman collection includes test scripts that automatically validate responses and set environment variables. To run all tests:

1. Click on the "Justice Minds API" collection
2. Click on the "Run" button
3. Select the requests you want to run
4. Click "Run Justice Minds API"
5. View the test results in the "Run Results" tab

## Troubleshooting

- **Authentication Issues**: Ensure that the `token` variable is set correctly. You may need to login again to get a fresh token.
- **404 Not Found**: Check that the API server is running and that the `baseUrl` variable is set correctly.
- **Connection Refused**: Ensure that the API server is running on the specified port.
- **CORS Errors**: If testing against a remote server, ensure that CORS is properly configured.

## Next Steps

After successfully testing the API, you can:

1. Automate these tests in a CI/CD pipeline
2. Create additional test cases for edge cases
3. Implement performance testing for high-load scenarios
