const { validationResult } = require('express-validator');
const { ApiError } = require('./errorHandler');

/**
 * Request validation middleware
 * Validates request data using express-validator
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const validateRequest = (req, res, next) => {
  const errors = validationResult(req);
  
  if (!errors.isEmpty()) {
    // Format validation errors
    const formattedErrors = errors.array().map(error => ({
      field: error.param,
      message: error.msg,
      value: error.value,
      location: error.location
    }));
    
    // Create a validation error with details
    throw ApiError.validationError('Validation failed', {
      validationErrors: formattedErrors
    });
  }
  
  next();
};

/**
 * Sanitize request body
 * Removes any fields not in the allowedFields array
 * @param {Array<string>} allowedFields - Array of allowed field names
 * @returns {Function} - Express middleware
 */
const sanitizeBody = (allowedFields) => {
  return (req, res, next) => {
    if (!req.body || typeof req.body !== 'object') {
      return next();
    }
    
    const sanitizedBody = {};
    
    // Only keep allowed fields
    for (const field of allowedFields) {
      if (req.body[field] !== undefined) {
        sanitizedBody[field] = req.body[field];
      }
    }
    
    // Replace request body with sanitized body
    req.body = sanitizedBody;
    next();
  };
};

/**
 * Validate ID parameter
 * Common middleware for validating UUID parameters
 * @param {string} paramName - Name of the parameter to validate
 * @returns {Function} - Express middleware
 */
const validateIdParam = (paramName = 'id') => {
  return (req, res, next) => {
    const id = req.params[paramName];
    
    // Check if ID is a valid UUID
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    
    if (!id || !uuidRegex.test(id)) {
      throw ApiError.badRequest(`Invalid ${paramName} parameter`, {
        field: paramName,
        value: id,
        expected: 'UUID'
      });
    }
    
    next();
  };
};

module.exports = {
  validateRequest,
  sanitizeBody,
  validateIdParam
};
