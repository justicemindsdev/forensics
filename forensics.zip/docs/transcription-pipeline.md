# Justice Minds Transcription Pipeline

This document explains the transcription pipeline used in the Justice Minds Forensic Transcription service.

## Overview

The transcription pipeline is responsible for converting audio/video recordings into text transcripts with timestamps, and then generating insights from those transcripts. The pipeline is designed to be asynchronous, scalable, and fault-tolerant.

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   Upload    │     │ Transcribe  │     │  Process    │     │  Generate   │
│  Recording  │ ──► │   Audio     │ ──► │ Transcript  │ ──► │  Insights   │
└─────────────┘     └─────────────┘     └─────────────┘     └─────────────┘
```

## Components

### 1. Recording Upload

- User uploads an audio/video file through the API
- File is stored in MinIO (S3-compatible storage)
- Recording metadata is stored in Redis
- User can request transcription of the recording

### 2. Transcription Job Queue

- When a user requests transcription, a job is created
- Job data is stored in Redis
- Job is published to RabbitMQ queue
- Transcription worker consumes jobs from the queue

### 3. Transcription Worker

- Runs as a separate process
- Consumes jobs from RabbitMQ queue
- Downloads recording from MinIO
- Sends audio to OpenAI Whisper API for transcription
- Processes and stores the transcript
- Updates job status in Redis

### 4. Transcript Processing

- Transcription data from Whisper API is processed
- Segments are extracted with timestamps
- Transcript is stored in MinIO as JSON
- Transcript metadata is stored in Redis

### 5. Insights Generation

- After transcription, insights are generated using OpenAI GPT-4
- Insights include summary, key points, action items, sentiment, and topics
- Insights are stored in MinIO as JSON
- Can be retrieved through the API

## Data Flow

1. **Recording Upload**:
   ```
   Client → API → MinIO (file) + Redis (metadata)
   ```

2. **Transcription Request**:
   ```
   Client → API → Redis (job data) → RabbitMQ (job queue)
   ```

3. **Transcription Processing**:
   ```
   RabbitMQ → Worker → MinIO (get file) → OpenAI Whisper API → MinIO (store transcript) + Redis (metadata)
   ```

4. **Insights Generation**:
   ```
   Worker → MinIO (get transcript) → OpenAI GPT-4 API → MinIO (store insights)
   ```

5. **Transcript Retrieval**:
   ```
   Client → API → Redis (metadata) → MinIO (transcript data) → Client
   ```

## Technologies Used

- **Storage**:
  - **MinIO**: Object storage for files (recordings, transcripts, insights)
  - **Redis**: Key-value store for metadata and job status

- **Message Queue**:
  - **RabbitMQ**: Asynchronous job processing

- **AI Services**:
  - **OpenAI Whisper**: Speech-to-text transcription
  - **OpenAI GPT-4**: Insights generation

## Job States

Transcription jobs can have the following states:

- `pending`: Job has been created and is waiting to be processed
  - *Average wait time: 5-30 seconds depending on queue load*
- `processing`: Job is currently being processed by a worker
  - *Average processing time: 1-5 minutes for a 30-minute recording*
- `completed`: Job has been successfully completed
- `failed`: Job has failed with an error
  - *Jobs are marked as failed after 3 retry attempts*

The system tracks time spent in each state, allowing for performance monitoring and optimization. Jobs typically transition from pending to processing within 30 seconds, while processing time scales linearly with recording length (approximately 10% of the recording duration).

## Error Handling

The transcription pipeline includes several error handling mechanisms:

1. **Job Retries**: Failed jobs can be retried automatically
   - *Maximum of 3 retry attempts with exponential backoff (30s, 2m, 5m)*
   - *Different retry strategies for different error types (API errors vs. processing errors)*
2. **Error Logging**: Detailed error logs are stored for debugging
   - *Logs include error type, stack trace, job metadata, and system state*
3. **Graceful Degradation**: If insights generation fails, the transcript is still available
   - *Insights can be generated on-demand later if initial generation fails*
4. **Status Tracking**: Job status is tracked and exposed through the API
   - *Includes detailed error messages and suggested resolution steps*

## Scaling

The transcription pipeline can be scaled in several ways:

1. **Multiple Workers**: Run multiple transcription workers to process jobs in parallel
   - *Current implementation supports up to 10 concurrent workers per instance*
2. **Horizontal Scaling**: Deploy workers across multiple machines
   - *Workers automatically register with RabbitMQ for load distribution*
3. **Queue Prioritization**: Implement priority queues for different types of jobs
   - *Currently in development, planned for next release*
   - *Will support premium users and time-sensitive transcriptions*
4. **Batch Processing**: Process multiple jobs in batches for efficiency
   - *Implemented for insights generation but not yet for transcription*

## Security

The transcription pipeline includes several security measures:

1. **Access Control**: Only authorized users can access recordings and transcripts
   - *Role-based access control with fine-grained permissions*
2. **Secure Storage**: Files are stored securely in MinIO
   - *All data is encrypted at rest using AES-256 encryption*
   - *TLS encryption for all data in transit*
3. **API Key Management**: OpenAI API keys are stored securely in AWS Secrets Manager
   - *Keys are rotated automatically every 30 days*
4. **Data Isolation**: Each user's data is isolated from other users
   - *Multi-tenant architecture with strict data segregation*
5. **Audit Logging**: All access to sensitive data is logged
   - *Logs include user ID, timestamp, action, and resource accessed*

## Monitoring

The transcription pipeline can be monitored through:

1. **Logs**: Detailed logs are generated at each step
   - *Structured JSON logs with consistent format for easy parsing*
2. **Status Endpoints**: API endpoints expose job status
   - *Real-time status updates via WebSocket for live monitoring*
3. **Metrics**: Performance metrics can be collected and visualized
   - *Key metrics tracked:*
     - *Job success rate (target: >99%)*
     - *Average processing time per minute of audio*
     - *Queue depth and wait times*
     - *API call latency and error rates*
     - *Worker CPU/memory utilization*
     - *Storage usage and growth rate*
4. **Alerts**: Alerts can be configured for failed jobs or system issues
   - *Configurable thresholds for different alert levels*
   - *Integration with PagerDuty, Slack, and email notifications*

## Future Improvements

Potential improvements to the transcription pipeline:

1. **Speaker Diarization**: Identify different speakers in the transcript
2. **Custom Models**: Train custom models for domain-specific terminology
3. **Real-time Transcription**: Implement streaming transcription for live meetings
4. **Advanced Insights**: Generate more advanced insights using specialized models
5. **Multi-language Support**: Support transcription and insights in multiple languages
