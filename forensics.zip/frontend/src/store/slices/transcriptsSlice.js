import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import transcriptService from '../../services/transcriptService';

// Initial state
const initialState = {
  transcripts: [],
  currentTranscript: null,
  insights: null,
  actionItems: [],
  summary: null,
  sentiment: null,
  loading: false,
  error: null,
  searchResults: [],
  searchLoading: false,
  searchError: null,
};

// Async thunks
export const fetchTranscripts = createAsyncThunk(
  'transcripts/fetchTranscripts',
  async ({ page = 1, limit = 10 } = {}, { rejectWithValue }) => {
    try {
      return await transcriptService.getTranscripts(page, limit);
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Failed to fetch transcripts');
    }
  }
);

export const fetchTranscriptById = createAsyncThunk(
  'transcripts/fetchTranscriptById',
  async (id, { rejectWithValue }) => {
    try {
      return await transcriptService.getTranscriptById(id);
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Failed to fetch transcript');
    }
  }
);

export const fetchTranscriptInsights = createAsyncThunk(
  'transcripts/fetchTranscriptInsights',
  async (id, { rejectWithValue }) => {
    try {
      return await transcriptService.getTranscriptInsights(id);
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Failed to fetch transcript insights');
    }
  }
);

export const fetchTranscriptActionItems = createAsyncThunk(
  'transcripts/fetchTranscriptActionItems',
  async (id, { rejectWithValue }) => {
    try {
      return await transcriptService.getTranscriptActionItems(id);
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Failed to fetch transcript action items');
    }
  }
);

export const fetchTranscriptSummary = createAsyncThunk(
  'transcripts/fetchTranscriptSummary',
  async (id, { rejectWithValue }) => {
    try {
      return await transcriptService.getTranscriptSummary(id);
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Failed to fetch transcript summary');
    }
  }
);

export const fetchTranscriptSentiment = createAsyncThunk(
  'transcripts/fetchTranscriptSentiment',
  async (id, { rejectWithValue }) => {
    try {
      return await transcriptService.getTranscriptSentiment(id);
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Failed to fetch transcript sentiment');
    }
  }
);

export const shareTranscript = createAsyncThunk(
  'transcripts/shareTranscript',
  async ({ id, emails }, { rejectWithValue }) => {
    try {
      return await transcriptService.shareTranscript(id, emails);
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Failed to share transcript');
    }
  }
);

export const searchTranscripts = createAsyncThunk(
  'transcripts/searchTranscripts',
  async (query, { rejectWithValue }) => {
    try {
      return await transcriptService.searchTranscripts(query);
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Failed to search transcripts');
    }
  }
);

// Transcripts slice
const transcriptsSlice = createSlice({
  name: 'transcripts',
  initialState,
  reducers: {
    resetTranscriptError: (state) => {
      state.error = null;
    },
    clearCurrentTranscript: (state) => {
      state.currentTranscript = null;
      state.insights = null;
      state.actionItems = [];
      state.summary = null;
      state.sentiment = null;
    },
    resetSearchResults: (state) => {
      state.searchResults = [];
      state.searchLoading = false;
      state.searchError = null;
    },
  },
  extraReducers: (builder) => {
    builder
      // Fetch Transcripts
      .addCase(fetchTranscripts.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchTranscripts.fulfilled, (state, action) => {
        state.loading = false;
        state.transcripts = action.payload;
      })
      .addCase(fetchTranscripts.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Fetch Transcript By ID
      .addCase(fetchTranscriptById.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchTranscriptById.fulfilled, (state, action) => {
        state.loading = false;
        state.currentTranscript = action.payload;
      })
      .addCase(fetchTranscriptById.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Fetch Transcript Insights
      .addCase(fetchTranscriptInsights.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchTranscriptInsights.fulfilled, (state, action) => {
        state.loading = false;
        state.insights = action.payload;
      })
      .addCase(fetchTranscriptInsights.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Fetch Transcript Action Items
      .addCase(fetchTranscriptActionItems.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchTranscriptActionItems.fulfilled, (state, action) => {
        state.loading = false;
        state.actionItems = action.payload;
      })
      .addCase(fetchTranscriptActionItems.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Fetch Transcript Summary
      .addCase(fetchTranscriptSummary.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchTranscriptSummary.fulfilled, (state, action) => {
        state.loading = false;
        state.summary = action.payload;
      })
      .addCase(fetchTranscriptSummary.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Fetch Transcript Sentiment
      .addCase(fetchTranscriptSentiment.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchTranscriptSentiment.fulfilled, (state, action) => {
        state.loading = false;
        state.sentiment = action.payload;
      })
      .addCase(fetchTranscriptSentiment.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Share Transcript
      .addCase(shareTranscript.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(shareTranscript.fulfilled, (state) => {
        state.loading = false;
      })
      .addCase(shareTranscript.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Search Transcripts
      .addCase(searchTranscripts.pending, (state) => {
        state.searchLoading = true;
        state.searchError = null;
      })
      .addCase(searchTranscripts.fulfilled, (state, action) => {
        state.searchLoading = false;
        state.searchResults = action.payload;
      })
      .addCase(searchTranscripts.rejected, (state, action) => {
        state.searchLoading = false;
        state.searchError = action.payload;
      });
  },
});

export const {
  resetTranscriptError,
  clearCurrentTranscript,
  resetSearchResults,
} = transcriptsSlice.actions;

export default transcriptsSlice.reducer;
