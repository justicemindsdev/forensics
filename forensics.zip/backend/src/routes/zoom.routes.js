const express = require('express');
const { body, param } = require('express-validator');
const zoomController = require('../controllers/zoom.controller');
const { validateRequest } = require('../middleware/validateRequest');
const { authenticate } = require('../middleware/authenticate');
const { validateZoomWebhook } = require('../middleware/validateZoomWebhook');

const router = express.Router();

// Routes that require authentication
router.use('/recordings', authenticate);

/**
 * @route GET /api/integrations/zoom/recordings
 * @desc Get all Zoom recordings for the current user
 * @access Private
 */
router.get('/recordings', zoomController.getZoomRecordings);

/**
 * @route POST /api/integrations/zoom/recordings/:meetingId/import
 * @desc Import a Zoom recording
 * @access Private
 */
router.post(
  '/recordings/:meetingId/import',
  [
    param('meetingId').not().isEmpty().withMessage('Meeting ID is required'),
    validateRequest
  ],
  zoomController.importZoomRecording
);

/**
 * @route POST /api/integrations/zoom/auth
 * @desc Authenticate with Zoom
 * @access Private
 */
router.post(
  '/auth',
  [
    body('code').not().isEmpty().withMessage('Authorization code is required'),
    validateRequest
  ],
  authenticate,
  zoomController.zoomAuth
);

/**
 * @route GET /api/integrations/zoom/auth/callback
 * @desc Zoom OAuth callback
 * @access Public
 */
router.get('/auth/callback', zoomController.zoomAuthCallback);

/**
 * @route POST /api/integrations/zoom/webhook
 * @desc Zoom webhook endpoint
 * @access Public (but verified with Zoom signature)
 */
router.post('/webhook', validateZoomWebhook, zoomController.zoomWebhook);

/**
 * @route GET /api/integrations/zoom/status
 * @desc Check Zoom integration status
 * @access Private
 */
router.get('/status', authenticate, zoomController.getZoomStatus);

/**
 * @route DELETE /api/integrations/zoom/disconnect
 * @desc Disconnect Zoom integration
 * @access Private
 */
router.delete('/disconnect', authenticate, zoomController.disconnectZoom);

module.exports = router;
