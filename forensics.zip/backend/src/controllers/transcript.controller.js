const { ApiError } = require('../middleware/errorHandler');
const logger = require('../utils/logger');
const { getMinioClient } = require('../services/minio');
const { getRedisClient } = require('../services/redis');
const TranscriptionService = require('../services/transcription');

/**
 * Transcript controller
 */
const transcriptController = {
  /**
   * Get all transcripts for the current user
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   * @param {Function} next - Express next function
   */
  getTranscripts: async (req, res, next) => {
    try {
      const redisClient = await getRedisClient();
      
      // Get recording IDs for user
      const recordingIds = await redisClient.sMembers(`user:${req.user.id}:recordings`);
      
      if (!recordingIds || recordingIds.length === 0) {
        return res.status(200).json({
          status: 'success',
          data: [],
        });
      }
      
      // Get transcripts for each recording
      const transcripts = [];
      
      for (const recordingId of recordingIds) {
        // Get transcript IDs for recording
        const transcriptIds = await redisClient.sMembers(`recording:${recordingId}:transcripts`);
        
        if (transcriptIds && transcriptIds.length > 0) {
          for (const transcriptId of transcriptIds) {
            // Get transcript metadata
            const transcriptData = await redisClient.get(`transcript:${transcriptId}`);
            
            if (transcriptData) {
              const transcript = JSON.parse(transcriptData);
              
              // Get recording metadata
              const recordingData = await redisClient.get(`recording:${recordingId}`);
              
              if (recordingData) {
                const recording = JSON.parse(recordingData);
                
                // Add recording info to transcript
                transcript.recording = {
                  id: recording.id,
                  title: recording.title,
                  description: recording.description,
                  createdAt: recording.createdAt,
                };
                
                transcripts.push(transcript);
              }
            }
          }
        }
      }
      
      // Sort transcripts by creation date (newest first)
      transcripts.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
      
      res.status(200).json({
        status: 'success',
        data: transcripts,
      });
    } catch (error) {
      next(error);
    }
  },

  /**
   * Get a transcript by ID
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   * @param {Function} next - Express next function
   */
  getTranscriptById: async (req, res, next) => {
    try {
      const { id } = req.params;
      const redisClient = await getRedisClient();
      
      // Get transcript metadata
      const transcriptMetadata = await redisClient.get(`transcript:${id}`);
      
      if (!transcriptMetadata) {
        throw ApiError.notFound('Transcript not found');
      }
      
      const metadata = JSON.parse(transcriptMetadata);
      const { recordingId } = metadata;
      
      // Get recording data to check access
      const recordingData = await redisClient.get(`recording:${recordingId}`);
      
      if (!recordingData) {
        throw ApiError.notFound('Recording not found');
      }
      
      const recording = JSON.parse(recordingData);
      
      // Check if user has access to this recording
      if (recording.userId !== req.user.id) {
        throw ApiError.forbidden('You do not have access to this transcript');
      }
      
      // Get full transcript data
      const transcript = await TranscriptionService.getTranscriptById(id);
      
      // Add recording info to transcript
      transcript.recording = {
        id: recording.id,
        title: recording.title,
        description: recording.description,
        createdAt: recording.createdAt,
      };
      
      res.status(200).json({
        status: 'success',
        data: transcript,
      });
    } catch (error) {
      next(error);
    }
  },

  /**
   * Get insights for a transcript
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   * @param {Function} next - Express next function
   */
  getTranscriptInsights: async (req, res, next) => {
    try {
      const { id } = req.params;
      const redisClient = await getRedisClient();
      
      // Get transcript metadata
      const transcriptMetadata = await redisClient.get(`transcript:${id}`);
      
      if (!transcriptMetadata) {
        throw ApiError.notFound('Transcript not found');
      }
      
      const metadata = JSON.parse(transcriptMetadata);
      const { recordingId } = metadata;
      
      // Get recording data to check access
      const recordingData = await redisClient.get(`recording:${recordingId}`);
      
      if (!recordingData) {
        throw ApiError.notFound('Recording not found');
      }
      
      const recording = JSON.parse(recordingData);
      
      // Check if user has access to this recording
      if (recording.userId !== req.user.id) {
        throw ApiError.forbidden('You do not have access to this transcript');
      }
      
      // Try to get existing insights
      try {
        const minioClient = await getMinioClient();
        const bucketName = process.env.MINIO_BUCKET || 'justice-minds';
        const objectName = `insights/${id}.json`;
        
        // Create temp file path
        const tempDir = require('os').tmpdir();
        const tempFilePath = require('path').join(tempDir, `insights_${id}_${Date.now()}.json`);
        
        // Download insights file
        await minioClient.fGetObject(bucketName, objectName, tempFilePath);
        
        // Read insights data
        const insightsData = JSON.parse(require('fs').readFileSync(tempFilePath, 'utf8'));
        
        // Clean up temp file
        require('fs').unlinkSync(tempFilePath);
        
        res.status(200).json({
          status: 'success',
          data: insightsData,
        });
      } catch (error) {
        // If insights don't exist, generate them
        logger.info(`Insights not found for transcript ${id}, generating new insights`);
        
        const insights = await TranscriptionService.generateInsights(id);
        
        res.status(200).json({
          status: 'success',
          data: {
            transcriptId: id,
            ...insights,
            createdAt: new Date().toISOString(),
          },
        });
      }
    } catch (error) {
      next(error);
    }
  },

  /**
   * Get action items for a transcript
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   * @param {Function} next - Express next function
   */
  getTranscriptActionItems: async (req, res, next) => {
    try {
      const { id } = req.params;
      
      // Get insights
      const insights = await transcriptController.getInsightsHelper(id, req.user.id);
      
      // Extract action items
      const actionItems = insights.action_items || [];
      
      res.status(200).json({
        status: 'success',
        data: actionItems,
      });
    } catch (error) {
      next(error);
    }
  },

  /**
   * Get summary for a transcript
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   * @param {Function} next - Express next function
   */
  getTranscriptSummary: async (req, res, next) => {
    try {
      const { id } = req.params;
      
      // Get insights
      const insights = await transcriptController.getInsightsHelper(id, req.user.id);
      
      // Extract summary and key points
      const summary = {
        summary: insights.summary,
        key_points: insights.key_points || [],
        topics: insights.topics || [],
        sentiment: insights.sentiment || 'neutral',
      };
      
      res.status(200).json({
        status: 'success',
        data: summary,
      });
    } catch (error) {
      next(error);
    }
  },

  /**
   * Share a transcript with other users
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   * @param {Function} next - Express next function
   */
  shareTranscript: async (req, res, next) => {
    try {
      const { id } = req.params;
      const { emails } = req.body;
      
      if (!emails || !Array.isArray(emails) || emails.length === 0) {
        throw ApiError.badRequest('No emails provided');
      }
      
      const redisClient = await getRedisClient();
      
      // Get transcript metadata
      const transcriptMetadata = await redisClient.get(`transcript:${id}`);
      
      if (!transcriptMetadata) {
        throw ApiError.notFound('Transcript not found');
      }
      
      const metadata = JSON.parse(transcriptMetadata);
      const { recordingId } = metadata;
      
      // Get recording data to check access
      const recordingData = await redisClient.get(`recording:${recordingId}`);
      
      if (!recordingData) {
        throw ApiError.notFound('Recording not found');
      }
      
      const recording = JSON.parse(recordingData);
      
      // Check if user has access to this recording
      if (recording.userId !== req.user.id) {
        throw ApiError.forbidden('You do not have access to this transcript');
      }
      
      // In a real implementation, this would send emails with a link to the transcript
      // For now, we'll just log the sharing action
      logger.info(`User ${req.user.id} shared transcript ${id} with ${emails.join(', ')}`);
      
      res.status(200).json({
        status: 'success',
        message: 'Transcript shared successfully',
        data: {
          transcriptId: id,
          sharedWith: emails,
        },
      });
    } catch (error) {
      next(error);
    }
  },

  /**
   * Search transcripts
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   * @param {Function} next - Express next function
   */
  searchTranscripts: async (req, res, next) => {
    try {
      const { q: query } = req.query;
      
      if (!query) {
        throw ApiError.badRequest('Search query is required');
      }
      
      const redisClient = await getRedisClient();
      
      // Get recording IDs for user
      const recordingIds = await redisClient.sMembers(`user:${req.user.id}:recordings`);
      
      if (!recordingIds || recordingIds.length === 0) {
        return res.status(200).json({
          status: 'success',
          data: [],
        });
      }
      
      // Get transcripts for each recording
      const results = [];
      
      for (const recordingId of recordingIds) {
        // Get transcript IDs for recording
        const transcriptIds = await redisClient.sMembers(`recording:${recordingId}:transcripts`);
        
        if (transcriptIds && transcriptIds.length > 0) {
          for (const transcriptId of transcriptIds) {
            try {
              // Get full transcript data
              const transcript = await TranscriptionService.getTranscriptById(transcriptId);
              
              // Search in transcript text
              if (transcript.text.toLowerCase().includes(query.toLowerCase())) {
                // Get recording metadata
                const recordingData = await redisClient.get(`recording:${recordingId}`);
                
                if (recordingData) {
                  const recording = JSON.parse(recordingData);
                  
                  // Find matching segments
                  const matchingSegments = transcript.segments.filter(segment => 
                    segment.text.toLowerCase().includes(query.toLowerCase())
                  );
                  
                  // Add to results
                  results.push({
                    transcriptId,
                    recordingId,
                    recordingTitle: recording.title,
                    recordingCreatedAt: recording.createdAt,
                    matchCount: matchingSegments.length,
                    segments: matchingSegments.map(segment => ({
                      id: segment.id,
                      start: segment.start,
                      end: segment.end,
                      text: segment.text,
                    })),
                  });
                }
              }
            } catch (error) {
              logger.error(`Error searching transcript ${transcriptId}:`, error);
              // Continue with next transcript
            }
          }
        }
      }
      
      // Sort results by match count (most matches first)
      results.sort((a, b) => b.matchCount - a.matchCount);
      
      res.status(200).json({
        status: 'success',
        data: results,
      });
    } catch (error) {
      next(error);
    }
  },

  /**
   * Helper function to get insights
   * @param {string} transcriptId - ID of the transcript
   * @param {string} userId - ID of the user
   * @returns {Promise<Object>} - Insights data
   */
  getInsightsHelper: async (transcriptId, userId) => {
    const redisClient = await getRedisClient();
    
    // Get transcript metadata
    const transcriptMetadata = await redisClient.get(`transcript:${transcriptId}`);
    
    if (!transcriptMetadata) {
      throw ApiError.notFound('Transcript not found');
    }
    
    const metadata = JSON.parse(transcriptMetadata);
    const { recordingId } = metadata;
    
    // Get recording data to check access
    const recordingData = await redisClient.get(`recording:${recordingId}`);
    
    if (!recordingData) {
      throw ApiError.notFound('Recording not found');
    }
    
    const recording = JSON.parse(recordingData);
    
    // Check if user has access to this recording
    if (recording.userId !== userId) {
      throw ApiError.forbidden('You do not have access to this transcript');
    }
    
    // Try to get existing insights
    try {
      const minioClient = await getMinioClient();
      const bucketName = process.env.MINIO_BUCKET || 'justice-minds';
      const objectName = `insights/${transcriptId}.json`;
      
      // Create temp file path
      const tempDir = require('os').tmpdir();
      const tempFilePath = require('path').join(tempDir, `insights_${transcriptId}_${Date.now()}.json`);
      
      // Download insights file
      await minioClient.fGetObject(bucketName, objectName, tempFilePath);
      
      // Read insights data
      const insightsData = JSON.parse(require('fs').readFileSync(tempFilePath, 'utf8'));
      
      // Clean up temp file
      require('fs').unlinkSync(tempFilePath);
      
      return insightsData;
    } catch (error) {
      // If insights don't exist, generate them
      logger.info(`Insights not found for transcript ${transcriptId}, generating new insights`);
      
      const insights = await TranscriptionService.generateInsights(transcriptId);
      
      return {
        transcriptId,
        ...insights,
        createdAt: new Date().toISOString(),
      };
    }
  },
};

module.exports = transcriptController;
