const Minio = require('minio');
const logger = require('../utils/logger');

let minioClient = null;

/**
 * Initialize MinIO client
 */
const setupMinIO = async () => {
  try {
    // Create MinIO client
    minioClient = new Minio.Client({
      endPoint: process.env.MINIO_ENDPOINT,
      port: parseInt(process.env.MINIO_PORT, 10),
      useSSL: process.env.MINIO_USE_SSL === 'true',
      accessKey: process.env.MINIO_ACCESS_KEY,
      secretKey: process.env.MINIO_SECRET_KEY
    });
    
    // Check if bucket exists, create if not
    const bucketExists = await minioClient.bucketExists(process.env.MINIO_BUCKET);
    
    if (!bucketExists) {
      await minioClient.makeBucket(process.env.MINIO_BUCKET);
      logger.info(`Bucket '${process.env.MINIO_BUCKET}' created`);
    } else {
      logger.info(`Bucket '${process.env.MINIO_BUCKET}' already exists`);
    }
    
    logger.info('MinIO client initialized');
    return minioClient;
  } catch (error) {
    logger.error('Failed to initialize MinIO client:', error);
    throw error;
  }
};

/**
 * Upload a file to MinIO
 * @param {string} filePath - Path to the file to upload
 * @param {string} objectName - Name to save the object as
 * @param {string} contentType - Content type of the file
 */
const uploadFile = async (filePath, objectName, contentType) => {
  try {
    if (!minioClient) {
      throw new Error('MinIO client not initialized');
    }
    
    await minioClient.fPutObject(
      process.env.MINIO_BUCKET,
      objectName,
      filePath,
      { 'Content-Type': contentType }
    );
    
    logger.debug(`File uploaded to MinIO: ${objectName}`);
    
    // Generate presigned URL for the uploaded object
    const url = await minioClient.presignedGetObject(
      process.env.MINIO_BUCKET,
      objectName,
      60 * 60 * 24 // 24 hours
    );
    
    return { objectName, url };
  } catch (error) {
    logger.error(`Failed to upload file to MinIO: ${objectName}`, error);
    throw error;
  }
};

/**
 * Download a file from MinIO
 * @param {string} objectName - Name of the object to download
 * @param {string} filePath - Path to save the file to
 */
const downloadFile = async (objectName, filePath) => {
  try {
    if (!minioClient) {
      throw new Error('MinIO client not initialized');
    }
    
    await minioClient.fGetObject(
      process.env.MINIO_BUCKET,
      objectName,
      filePath
    );
    
    logger.debug(`File downloaded from MinIO: ${objectName}`);
    return filePath;
  } catch (error) {
    logger.error(`Failed to download file from MinIO: ${objectName}`, error);
    throw error;
  }
};

/**
 * Get a presigned URL for an object
 * @param {string} objectName - Name of the object
 * @param {number} expirySeconds - Expiry time in seconds
 */
const getPresignedUrl = async (objectName, expirySeconds = 60 * 60) => {
  try {
    if (!minioClient) {
      throw new Error('MinIO client not initialized');
    }
    
    const url = await minioClient.presignedGetObject(
      process.env.MINIO_BUCKET,
      objectName,
      expirySeconds
    );
    
    logger.debug(`Presigned URL generated for: ${objectName}`);
    return url;
  } catch (error) {
    logger.error(`Failed to generate presigned URL for: ${objectName}`, error);
    throw error;
  }
};

/**
 * Delete an object from MinIO
 * @param {string} objectName - Name of the object to delete
 */
const deleteFile = async (objectName) => {
  try {
    if (!minioClient) {
      throw new Error('MinIO client not initialized');
    }
    
    await minioClient.removeObject(
      process.env.MINIO_BUCKET,
      objectName
    );
    
    logger.debug(`File deleted from MinIO: ${objectName}`);
    return true;
  } catch (error) {
    logger.error(`Failed to delete file from MinIO: ${objectName}`, error);
    throw error;
  }
};

/**
 * List objects in MinIO bucket
 * @param {string} prefix - Prefix to filter objects by
 */
const listFiles = async (prefix = '') => {
  try {
    if (!minioClient) {
      throw new Error('MinIO client not initialized');
    }
    
    const objects = [];
    const stream = minioClient.listObjects(
      process.env.MINIO_BUCKET,
      prefix,
      true
    );
    
    return new Promise((resolve, reject) => {
      stream.on('data', (obj) => {
        objects.push(obj);
      });
      
      stream.on('error', (err) => {
        logger.error('Error listing objects:', err);
        reject(err);
      });
      
      stream.on('end', () => {
        resolve(objects);
      });
    });
  } catch (error) {
    logger.error('Failed to list files from MinIO', error);
    throw error;
  }
};

module.exports = {
  setupMinIO,
  uploadFile,
  downloadFile,
  getPresignedUrl,
  deleteFile,
  listFiles
};
