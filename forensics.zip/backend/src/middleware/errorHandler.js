const logger = require('../utils/logger');

/**
 * Error codes for consistent error handling
 */
const ErrorCodes = {
  BAD_REQUEST: 400,
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  METHOD_NOT_ALLOWED: 405,
  CONFLICT: 409,
  UNPROCESSABLE_ENTITY: 422,
  TOO_MANY_REQUESTS: 429,
  INTERNAL_SERVER_ERROR: 500,
  SERVICE_UNAVAILABLE: 503,
};

/**
 * Custom error class for API errors
 */
class ApiError extends Error {
  /**
   * Create a new API error
   * @param {number} statusCode - HTTP status code
   * @param {string} message - Error message
   * @param {boolean} isOperational - Whether this is an operational error
   * @param {string} errorCode - Error code for client identification
   * @param {Object} details - Additional error details
   * @param {string} stack - Error stack trace
   */
  constructor(
    statusCode,
    message,
    isOperational = true,
    errorCode = null,
    details = null,
    stack = ''
  ) {
    super(message);
    this.statusCode = statusCode;
    this.isOperational = isOperational;
    this.errorCode = errorCode || `ERR_${statusCode}`;
    this.details = details;
    
    if (stack) {
      this.stack = stack;
    } else {
      Error.captureStackTrace(this, this.constructor);
    }
  }

  /**
   * Create a 400 Bad Request error
   * @param {string} message - Error message
   * @param {Object} details - Additional error details
   * @returns {ApiError} - Bad Request error
   */
  static badRequest(message = 'Bad Request', details = null) {
    return new ApiError(
      ErrorCodes.BAD_REQUEST,
      message,
      true,
      'ERR_BAD_REQUEST',
      details
    );
  }

  /**
   * Create a 401 Unauthorized error
   * @param {string} message - Error message
   * @param {Object} details - Additional error details
   * @returns {ApiError} - Unauthorized error
   */
  static unauthorized(message = 'Unauthorized', details = null) {
    return new ApiError(
      ErrorCodes.UNAUTHORIZED,
      message,
      true,
      'ERR_UNAUTHORIZED',
      details
    );
  }

  /**
   * Create a 403 Forbidden error
   * @param {string} message - Error message
   * @param {Object} details - Additional error details
   * @returns {ApiError} - Forbidden error
   */
  static forbidden(message = 'Forbidden', details = null) {
    return new ApiError(
      ErrorCodes.FORBIDDEN,
      message,
      true,
      'ERR_FORBIDDEN',
      details
    );
  }

  /**
   * Create a 404 Not Found error
   * @param {string} message - Error message
   * @param {Object} details - Additional error details
   * @returns {ApiError} - Not Found error
   */
  static notFound(message = 'Resource Not Found', details = null) {
    return new ApiError(
      ErrorCodes.NOT_FOUND,
      message,
      true,
      'ERR_NOT_FOUND',
      details
    );
  }

  /**
   * Create a 409 Conflict error
   * @param {string} message - Error message
   * @param {Object} details - Additional error details
   * @returns {ApiError} - Conflict error
   */
  static conflict(message = 'Resource Conflict', details = null) {
    return new ApiError(
      ErrorCodes.CONFLICT,
      message,
      true,
      'ERR_CONFLICT',
      details
    );
  }

  /**
   * Create a 422 Unprocessable Entity error
   * @param {string} message - Error message
   * @param {Object} details - Additional error details
   * @returns {ApiError} - Unprocessable Entity error
   */
  static validationError(message = 'Validation Error', details = null) {
    return new ApiError(
      ErrorCodes.UNPROCESSABLE_ENTITY,
      message,
      true,
      'ERR_VALIDATION',
      details
    );
  }

  /**
   * Create a 429 Too Many Requests error
   * @param {string} message - Error message
   * @param {Object} details - Additional error details
   * @returns {ApiError} - Too Many Requests error
   */
  static tooManyRequests(message = 'Too Many Requests', details = null) {
    return new ApiError(
      ErrorCodes.TOO_MANY_REQUESTS,
      message,
      true,
      'ERR_TOO_MANY_REQUESTS',
      details
    );
  }

  /**
   * Create a 500 Internal Server Error
   * @param {string} message - Error message
   * @param {Object} details - Additional error details
   * @returns {ApiError} - Internal Server Error
   */
  static internal(message = 'Internal Server Error', details = null) {
    return new ApiError(
      ErrorCodes.INTERNAL_SERVER_ERROR,
      message,
      false,
      'ERR_INTERNAL',
      details
    );
  }

  /**
   * Create a 503 Service Unavailable error
   * @param {string} message - Error message
   * @param {Object} details - Additional error details
   * @returns {ApiError} - Service Unavailable error
   */
  static serviceUnavailable(message = 'Service Unavailable', details = null) {
    return new ApiError(
      ErrorCodes.SERVICE_UNAVAILABLE,
      message,
      true,
      'ERR_SERVICE_UNAVAILABLE',
      details
    );
  }
}

/**
 * Error handler middleware
 */
const errorHandler = (err, req, res, next) => {
  let error = err;
  
  // If not an ApiError, convert to one
  if (!(error instanceof ApiError)) {
    const statusCode = error.statusCode || ErrorCodes.INTERNAL_SERVER_ERROR;
    const message = error.message || 'Internal Server Error';
    let errorDetails = null;
    
    // Extract validation errors from express-validator
    if (error.errors && Array.isArray(error.errors)) {
      errorDetails = {
        validationErrors: error.errors.map(err => ({
          field: err.param,
          message: err.msg,
          value: err.value
        }))
      };
    }
    
    error = new ApiError(
      statusCode,
      message,
      statusCode < 500, // Operational if not 5xx
      null,
      errorDetails,
      error.stack
    );
  }

  // Prepare response object
  const response = {
    status: 'error',
    statusCode: error.statusCode,
    message: error.message,
    errorCode: error.errorCode,
  };
  
  // Add details if available
  if (error.details) {
    response.details = error.details;
  }
  
  // Add stack trace in development
  if (process.env.NODE_ENV === 'development') {
    response.stack = error.stack;
  }

  // Log the error (with different levels based on severity)
  const logMethod = error.statusCode >= 500 ? 'error' : 'warn';
  const logData = {
    statusCode: error.statusCode,
    message: error.message,
    errorCode: error.errorCode,
    path: req.path,
    method: req.method,
    ip: req.ip,
    userId: req.user?.id || 'unauthenticated',
  };
  
  if (error.details) {
    logData.details = error.details;
  }
  
  logger[logMethod]('API Error', logData);
  
  if (error.statusCode >= 500) {
    logger.error(error.stack);
  }

  // Send error response
  res.status(error.statusCode).json(response);
};

module.exports = {
  ApiError,
  ErrorCodes,
  errorHandler
};
