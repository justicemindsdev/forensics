import fs from 'fs';
import path from 'path';
import axios from 'axios';
import * as grainApi from './grainApiClient';

/**
 * Utility functions for working with API Grain data sources
 * This module reads URLs from files in the apigrain directory and provides
 * functions to fetch data from these sources.
 * 
 * Special handling is provided for the Grain API (grain.com).
 */

// Directory where API source files are stored
const API_GRAIN_DIR = path.join(process.cwd(), 'frontend-new', 'apigrain');

/**
 * Get all API source URLs from files in the apigrain directory
 * @returns {Record<string, string>} Object with filename as key and URL as value
 */
export const getApiSources = (): Record<string, string> => {
  try {
    // Get all files in the apigrain directory
    const files = fs.readdirSync(API_GRAIN_DIR);
    
    // Create an object to store the sources
    const sources: Record<string, string> = {};
    
    // Read each file and store its content as a URL
    files.forEach(file => {
      if (file === 'apiGrainUtils.ts' || file.startsWith('.')) return; // Skip this utility file and hidden files
      
      const filePath = path.join(API_GRAIN_DIR, file);
      const stats = fs.statSync(filePath);
      
      // Only process files, not directories
      if (stats.isFile()) {
        try {
          const content = fs.readFileSync(filePath, 'utf8').trim();
          sources[file] = content;
        } catch (error) {
          console.error(`Error reading file ${file}:`, error);
        }
      }
    });
    
    return sources;
  } catch (error) {
    console.error('Error reading API sources:', error);
    return {};
  }
};

/**
 * Fetch data from a specific API source
 * @param {string} sourceName - Name of the source file (without path)
 * @param {object} options - Optional parameters for the request
 * @returns {Promise<any>} Promise that resolves to the fetched data
 */
export const fetchFromSource = async (sourceName: string, options: any = {}): Promise<any> => {
  const sources = getApiSources();
  
  if (!sources[sourceName]) {
    throw new Error(`API source '${sourceName}' not found`);
  }
  
  // Special handling for Grain API
  if (sourceName === 'grain.com') {
    return fetchFromGrainApi(options);
  }
  
  const url = sources[sourceName];
  
  try {
    const response = await axios.get(url);
    return response.data;
  } catch (error) {
    console.error(`Error fetching from ${url}:`, error);
    throw error;
  }
};

/**
 * Fetch data from the Grain API
 * @param {object} options - Optional parameters for the request
 * @returns {Promise<any>} Promise that resolves to the fetched data
 */
export const fetchFromGrainApi = async (options: any = {}): Promise<any> => {
  try {
    // Determine which Grain API endpoint to call based on options
    if (options.recordingId) {
      // Fetch a specific recording
      return await grainApi.getRecording(options.recordingId, options);
    } else if (options.endpoint === 'me') {
      // Fetch current user info
      return await grainApi.getCurrentUser();
    } else if (options.endpoint === 'views') {
      // Fetch views
      return await grainApi.getViews(options);
    } else if (options.endpoint === 'hooks') {
      // Fetch hooks
      return await grainApi.getHooks();
    } else {
      // Default to fetching recordings
      return await grainApi.getRecordings(options);
    }
  } catch (error) {
    console.error('Error fetching from Grain API:', error);
    throw error;
  }
};

/**
 * Fetch data from all API sources
 * @returns {Promise<Record<string, any>>} Promise that resolves to an object with source name as key and fetched data as value
 */
export const fetchFromAllSources = async (): Promise<Record<string, any>> => {
  const sources = getApiSources();
  const results: Record<string, any> = {};
  
  await Promise.all(
    Object.entries(sources).map(async ([name, url]) => {
      try {
        if (name === 'grain.com') {
          // Special handling for Grain API
          const userData = await grainApi.getCurrentUser();
          const recordings = await grainApi.getRecordings();
          
          results[name] = {
            user: userData,
            recordings: recordings,
            url: url
          };
        } else {
          const response = await axios.get(url);
          results[name] = response.data;
        }
      } catch (error) {
        console.error(`Error fetching from ${name}:`, error);
        results[name] = { error: true, message: (error as Error).message };
      }
    })
  );
  
  return results;
};

/**
 * Get a list of all available API source names
 * @returns {string[]} Array of source names
 */
export const getSourceNames = (): string[] => {
  return Object.keys(getApiSources());
};

/**
 * Check if a source exists
 * @param {string} sourceName - Name of the source file
 * @returns {boolean} True if the source exists
 */
export const sourceExists = (sourceName: string): boolean => {
  const sources = getApiSources();
  return !!sources[sourceName];
};

/**
 * Get the URL for a specific source
 * @param {string} sourceName - Name of the source file
 * @returns {string|null} URL of the source or null if not found
 */
export const getSourceUrl = (sourceName: string): string | null => {
  const sources = getApiSources();
  return sources[sourceName] || null;
};
