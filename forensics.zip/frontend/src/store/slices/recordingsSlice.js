import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import recordingService from '../../services/recordingService';

// Initial state
const initialState = {
  recordings: [],
  currentRecording: null,
  loading: false,
  error: null,
  uploadProgress: 0,
  transcriptionStatus: null,
};

// Async thunks
export const fetchRecordings = createAsyncThunk(
  'recordings/fetchRecordings',
  async (_, { rejectWithValue }) => {
    try {
      return await recordingService.getRecordings();
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Failed to fetch recordings');
    }
  }
);

export const fetchRecordingById = createAsyncThunk(
  'recordings/fetchRecordingById',
  async (id, { rejectWithValue }) => {
    try {
      return await recordingService.getRecordingById(id);
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Failed to fetch recording');
    }
  }
);

export const uploadRecording = createAsyncThunk(
  'recordings/uploadRecording',
  async ({ file, title, description }, { dispatch, rejectWithValue }) => {
    try {
      // Set up progress tracking
      const onUploadProgress = (progressEvent) => {
        const percentCompleted = Math.round(
          (progressEvent.loaded * 100) / progressEvent.total
        );
        dispatch(setUploadProgress(percentCompleted));
      };
      
      return await recordingService.uploadRecording(
        file,
        title,
        description,
        onUploadProgress
      );
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Failed to upload recording');
    }
  }
);

export const transcribeRecording = createAsyncThunk(
  'recordings/transcribeRecording',
  async (id, { rejectWithValue }) => {
    try {
      return await recordingService.transcribeRecording(id);
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Failed to transcribe recording');
    }
  }
);

export const fetchTranscriptionStatus = createAsyncThunk(
  'recordings/fetchTranscriptionStatus',
  async (id, { rejectWithValue }) => {
    try {
      return await recordingService.getTranscriptionStatus(id);
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Failed to fetch transcription status');
    }
  }
);

export const deleteRecording = createAsyncThunk(
  'recordings/deleteRecording',
  async (id, { rejectWithValue }) => {
    try {
      await recordingService.deleteRecording(id);
      return id;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Failed to delete recording');
    }
  }
);

// Recordings slice
const recordingsSlice = createSlice({
  name: 'recordings',
  initialState,
  reducers: {
    setUploadProgress: (state, action) => {
      state.uploadProgress = action.payload;
    },
    resetUploadProgress: (state) => {
      state.uploadProgress = 0;
    },
    resetRecordingError: (state) => {
      state.error = null;
    },
    clearCurrentRecording: (state) => {
      state.currentRecording = null;
    },
  },
  extraReducers: (builder) => {
    builder
      // Fetch Recordings
      .addCase(fetchRecordings.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchRecordings.fulfilled, (state, action) => {
        state.loading = false;
        state.recordings = action.payload;
      })
      .addCase(fetchRecordings.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Fetch Recording By ID
      .addCase(fetchRecordingById.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchRecordingById.fulfilled, (state, action) => {
        state.loading = false;
        state.currentRecording = action.payload;
      })
      .addCase(fetchRecordingById.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Upload Recording
      .addCase(uploadRecording.pending, (state) => {
        state.loading = true;
        state.error = null;
        state.uploadProgress = 0;
      })
      .addCase(uploadRecording.fulfilled, (state, action) => {
        state.loading = false;
        state.recordings.push(action.payload);
        state.currentRecording = action.payload;
        state.uploadProgress = 100;
      })
      .addCase(uploadRecording.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
        state.uploadProgress = 0;
      })
      
      // Transcribe Recording
      .addCase(transcribeRecording.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(transcribeRecording.fulfilled, (state, action) => {
        state.loading = false;
        state.transcriptionStatus = action.payload.status;
      })
      .addCase(transcribeRecording.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Fetch Transcription Status
      .addCase(fetchTranscriptionStatus.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchTranscriptionStatus.fulfilled, (state, action) => {
        state.loading = false;
        state.transcriptionStatus = action.payload.status;
      })
      .addCase(fetchTranscriptionStatus.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Delete Recording
      .addCase(deleteRecording.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteRecording.fulfilled, (state, action) => {
        state.loading = false;
        state.recordings = state.recordings.filter(
          (recording) => recording.id !== action.payload
        );
        if (state.currentRecording && state.currentRecording.id === action.payload) {
          state.currentRecording = null;
        }
      })
      .addCase(deleteRecording.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export const {
  setUploadProgress,
  resetUploadProgress,
  resetRecordingError,
  clearCurrentRecording,
} = recordingsSlice.actions;

export default recordingsSlice.reducer;
