import axios from 'axios';

/**
 * Grain API Client
 * 
 * This client provides methods for interacting with the Grain API.
 * It uses a Personal Access Token for authentication.
 * 
 * API Documentation: https://grainhq.notion.site/Grain-Public-API-877184aa82b54c77a875083c1b560de9
 */

// API base URL
const API_BASE_URL = 'https://api.grain.com';

// Personal Access Token - should be loaded from environment variables in production
const API_TOKEN = process.env.GRAIN_API_TOKEN || '';

// Create an axios instance with the base URL and authentication header
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Authorization': `Bearer ${API_TOKEN}`,
    'Content-Type': 'application/json',
  },
});

/**
 * Get the current user's information
 * @returns Promise with user data
 */
export const getCurrentUser = async () => {
  try {
    const response = await apiClient.get('/_/public-api/me');
    return response.data;
  } catch (error) {
    console.error('Error fetching current user:', error);
    throw error;
  }
};

/**
 * Get a list of recordings
 * @param options Optional parameters for the request
 * @returns Promise with recordings data
 */
export const getRecordings = async (options: {
  cursor?: string;
  include_highlights?: boolean;
  include_participants?: boolean;
  include_calendar_id?: boolean;
  attendance?: 'hosted' | 'attended';
} = {}) => {
  try {
    const response = await apiClient.get('/_/public-api/recordings', {
      params: options,
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching recordings:', error);
    throw error;
  }
};

/**
 * Get a specific recording by ID
 * @param id Recording ID
 * @param options Optional parameters for the request
 * @returns Promise with recording data
 */
export const getRecording = async (id: string, options: {
  include_highlights?: boolean;
  include_participants?: boolean;
  include_owners?: boolean;
  include_calendar_id?: boolean;
  transcript_format?: 'json' | 'vtt';
  intelligence_notes_format?: 'json' | 'md' | 'text';
  allowed_intelligence_notes?: string[];
} = {}) => {
  try {
    const response = await apiClient.get(`/_/public-api/recordings/${id}`, {
      params: options,
    });
    return response.data;
  } catch (error) {
    console.error(`Error fetching recording ${id}:`, error);
    throw error;
  }
};

/**
 * Get a recording's transcript in VTT format
 * @param id Recording ID
 * @returns Promise with VTT transcript data
 */
export const getRecordingTranscriptVtt = async (id: string) => {
  try {
    const response = await apiClient.get(`/_/public-api/recordings/${id}/transcript.vtt`);
    return response.data;
  } catch (error) {
    console.error(`Error fetching VTT transcript for recording ${id}:`, error);
    throw error;
  }
};

/**
 * Get a recording's transcript in SRT format
 * @param id Recording ID
 * @returns Promise with SRT transcript data
 */
export const getRecordingTranscriptSrt = async (id: string) => {
  try {
    const response = await apiClient.get(`/_/public-api/recordings/${id}/transcript.srt`);
    return response.data;
  } catch (error) {
    console.error(`Error fetching SRT transcript for recording ${id}:`, error);
    throw error;
  }
};

/**
 * Get a list of views (saved filters)
 * @param options Optional parameters for the request
 * @returns Promise with views data
 */
export const getViews = async (options: {
  cursor?: string;
  type_filter?: 'recordings' | 'highlights' | 'stories';
} = {}) => {
  try {
    const response = await apiClient.get('/_/public-api/views', {
      params: options,
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching views:', error);
    throw error;
  }
};

/**
 * Create a REST hook
 * @param hookUrl URL to be called when the event is triggered
 * @param viewId View ID obtained from getViews
 * @param actions Optional list of actions that will cause the REST hook to fire
 * @returns Promise with hook data
 */
export const createHook = async (
  hookUrl: string,
  viewId: string,
  actions?: Array<'added' | 'updated' | 'removed'>
) => {
  try {
    const response = await apiClient.post('/_/public-api/hooks', {
      version: 2,
      hook_url: hookUrl,
      view_id: viewId,
      actions,
    });
    return response.data;
  } catch (error) {
    console.error('Error creating hook:', error);
    throw error;
  }
};

/**
 * Get a list of webhooks
 * @returns Promise with hooks data
 */
export const getHooks = async () => {
  try {
    const response = await apiClient.get('/_/public-api/hooks');
    return response.data;
  } catch (error) {
    console.error('Error fetching hooks:', error);
    throw error;
  }
};

/**
 * Delete a webhook
 * @param id Hook ID
 * @returns Promise with success status
 */
export const deleteHook = async (id: string) => {
  try {
    const response = await apiClient.delete(`/_/public-api/hooks/${id}`);
    return response.data;
  } catch (error) {
    console.error(`Error deleting hook ${id}:`, error);
    throw error;
  }
};

// Export the API client for advanced usage
export default apiClient;
