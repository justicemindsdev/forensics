import apiClient from './apiClient';

/**
 * Recording service for handling recording-related operations
 */
const recordingService = {
  /**
   * Get all recordings
   * @returns {Promise<Array>} - List of recordings
   */
  getRecordings: async () => {
    const response = await apiClient.get('/recordings');
    return response.data;
  },
  
  /**
   * Get a recording by ID
   * @param {string} id - Recording ID
   * @returns {Promise<Object>} - Recording data
   */
  getRecordingById: async (id) => {
    const response = await apiClient.get(`/recordings/${id}`);
    return response.data;
  },
  
  /**
   * Upload a recording
   * @param {File} file - Recording file
   * @param {string} title - Recording title
   * @param {string} description - Recording description (optional)
   * @param {Function} onUploadProgress - Progress callback (optional)
   * @returns {Promise<Object>} - Uploaded recording data
   */
  uploadRecording: async (file, title, description = '', onUploadProgress = null) => {
    // Create form data
    const formData = new FormData();
    formData.append('file', file);
    formData.append('title', title);
    if (description) {
      formData.append('description', description);
    }
    
    // Upload with progress tracking
    const response = await apiClient.post('/recordings', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
      onUploadProgress: onUploadProgress
        ? (progressEvent) => {
            const percentCompleted = Math.round(
              (progressEvent.loaded * 100) / progressEvent.total
            );
            onUploadProgress(percentCompleted);
          }
        : undefined,
    });
    
    return response.data;
  },
  
  /**
   * Update a recording
   * @param {string} id - Recording ID
   * @param {Object} data - Data to update (title, description)
   * @returns {Promise<Object>} - Updated recording data
   */
  updateRecording: async (id, data) => {
    const response = await apiClient.put(`/recordings/${id}`, data);
    return response.data;
  },
  
  /**
   * Delete a recording
   * @param {string} id - Recording ID
   * @returns {Promise<void>}
   */
  deleteRecording: async (id) => {
    await apiClient.delete(`/recordings/${id}`);
  },
  
  /**
   * Transcribe a recording
   * @param {string} id - Recording ID
   * @returns {Promise<Object>} - Transcription job data
   */
  transcribeRecording: async (id) => {
    const response = await apiClient.post(`/recordings/${id}/transcribe`);
    return response.data;
  },
  
  /**
   * Get transcription status
   * @param {string} id - Recording ID
   * @returns {Promise<Object>} - Transcription status
   */
  getTranscriptionStatus: async (id) => {
    const response = await apiClient.get(`/recordings/${id}/status`);
    return response.data;
  },
  
  /**
   * Get a presigned URL for a recording file
   * @param {string} id - Recording ID
   * @returns {Promise<string>} - Presigned URL
   */
  getRecordingUrl: async (id) => {
    const response = await apiClient.get(`/recordings/${id}/url`);
    return response.data.url;
  },
};

export default recordingService;
