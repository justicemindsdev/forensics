import { configureStore } from '@reduxjs/toolkit';
import authReducer from './slices/authSlice';
import socketReducer from './slices/socketSlice';
import recordingsReducer from './slices/recordingsSlice';
import transcriptsReducer from './slices/transcriptsSlice';
import integrationsReducer from './slices/integrationsSlice';

// Configure Redux store
export const store = configureStore({
  reducer: {
    auth: authReducer,
    socket: socketReducer,
    recordings: recordingsReducer,
    transcripts: transcriptsReducer,
    integrations: integrationsReducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        // Ignore non-serializable values in the socket slice
        ignoredActions: ['socket/setSocket'],
        ignoredPaths: ['socket.socket'],
      },
    }),
});
