import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import zoomService from '../../services/zoomService';
import googleDriveService from '../../services/googleDriveService';

// Initial state
const initialState = {
  // Zoom
  zoomStatus: null,
  zoomRecordings: [],
  zoomLoading: false,
  zoomError: null,
  
  // Google Drive
  googleDriveStatus: null,
  googleDriveFiles: [],
  googleDriveLoading: false,
  googleDriveError: null,
  
  // Common
  importLoading: false,
  importError: null,
};

// Zoom async thunks
export const getZoomStatus = createAsyncThunk(
  'integrations/getZoomStatus',
  async (_, { rejectWithValue }) => {
    try {
      return await zoomService.getZoomStatus();
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Failed to get Zoom status');
    }
  }
);

export const authenticateZoom = createAsyncThunk(
  'integrations/authenticateZoom',
  async (code, { rejectWithValue }) => {
    try {
      return await zoomService.authenticateZoom(code);
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Failed to authenticate with Zoom');
    }
  }
);

export const disconnectZoom = createAsyncThunk(
  'integrations/disconnectZoom',
  async (_, { rejectWithValue }) => {
    try {
      await zoomService.disconnectZoom();
      return true;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Failed to disconnect Zoom');
    }
  }
);

export const getZoomRecordings = createAsyncThunk(
  'integrations/getZoomRecordings',
  async (_, { rejectWithValue }) => {
    try {
      return await zoomService.getZoomRecordings();
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Failed to get Zoom recordings');
    }
  }
);

export const importZoomRecording = createAsyncThunk(
  'integrations/importZoomRecording',
  async ({ meetingId, title, description }, { rejectWithValue }) => {
    try {
      return await zoomService.importZoomRecording(meetingId, title, description);
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Failed to import Zoom recording');
    }
  }
);

// Google Drive async thunks
export const getGoogleDriveStatus = createAsyncThunk(
  'integrations/getGoogleDriveStatus',
  async (_, { rejectWithValue }) => {
    try {
      return await googleDriveService.getGoogleDriveStatus();
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Failed to get Google Drive status');
    }
  }
);

export const authenticateGoogleDrive = createAsyncThunk(
  'integrations/authenticateGoogleDrive',
  async (code, { rejectWithValue }) => {
    try {
      return await googleDriveService.authenticateGoogleDrive(code);
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Failed to authenticate with Google Drive');
    }
  }
);

export const disconnectGoogleDrive = createAsyncThunk(
  'integrations/disconnectGoogleDrive',
  async (_, { rejectWithValue }) => {
    try {
      await googleDriveService.disconnectGoogleDrive();
      return true;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Failed to disconnect Google Drive');
    }
  }
);

export const getGoogleDriveFiles = createAsyncThunk(
  'integrations/getGoogleDriveFiles',
  async ({ mimeType, pageSize, pageToken } = {}, { rejectWithValue }) => {
    try {
      return await googleDriveService.getGoogleDriveFiles(mimeType, pageSize, pageToken);
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Failed to get Google Drive files');
    }
  }
);

export const searchGoogleDriveFiles = createAsyncThunk(
  'integrations/searchGoogleDriveFiles',
  async ({ query, mimeType }, { rejectWithValue }) => {
    try {
      return await googleDriveService.searchGoogleDriveFiles(query, mimeType);
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Failed to search Google Drive files');
    }
  }
);

export const importGoogleDriveFile = createAsyncThunk(
  'integrations/importGoogleDriveFile',
  async ({ fileId, title, description }, { rejectWithValue }) => {
    try {
      return await googleDriveService.importGoogleDriveFile(fileId, title, description);
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Failed to import Google Drive file');
    }
  }
);

// Integrations slice
const integrationsSlice = createSlice({
  name: 'integrations',
  initialState,
  reducers: {
    resetZoomError: (state) => {
      state.zoomError = null;
    },
    resetGoogleDriveError: (state) => {
      state.googleDriveError = null;
    },
    resetImportError: (state) => {
      state.importError = null;
    },
  },
  extraReducers: (builder) => {
    builder
      // Zoom Status
      .addCase(getZoomStatus.pending, (state) => {
        state.zoomLoading = true;
        state.zoomError = null;
      })
      .addCase(getZoomStatus.fulfilled, (state, action) => {
        state.zoomLoading = false;
        state.zoomStatus = action.payload;
      })
      .addCase(getZoomStatus.rejected, (state, action) => {
        state.zoomLoading = false;
        state.zoomError = action.payload;
      })
      
      // Authenticate Zoom
      .addCase(authenticateZoom.pending, (state) => {
        state.zoomLoading = true;
        state.zoomError = null;
      })
      .addCase(authenticateZoom.fulfilled, (state, action) => {
        state.zoomLoading = false;
        state.zoomStatus = action.payload;
      })
      .addCase(authenticateZoom.rejected, (state, action) => {
        state.zoomLoading = false;
        state.zoomError = action.payload;
      })
      
      // Disconnect Zoom
      .addCase(disconnectZoom.pending, (state) => {
        state.zoomLoading = true;
        state.zoomError = null;
      })
      .addCase(disconnectZoom.fulfilled, (state) => {
        state.zoomLoading = false;
        state.zoomStatus = null;
        state.zoomRecordings = [];
      })
      .addCase(disconnectZoom.rejected, (state, action) => {
        state.zoomLoading = false;
        state.zoomError = action.payload;
      })
      
      // Get Zoom Recordings
      .addCase(getZoomRecordings.pending, (state) => {
        state.zoomLoading = true;
        state.zoomError = null;
      })
      .addCase(getZoomRecordings.fulfilled, (state, action) => {
        state.zoomLoading = false;
        state.zoomRecordings = action.payload;
      })
      .addCase(getZoomRecordings.rejected, (state, action) => {
        state.zoomLoading = false;
        state.zoomError = action.payload;
      })
      
      // Import Zoom Recording
      .addCase(importZoomRecording.pending, (state) => {
        state.importLoading = true;
        state.importError = null;
      })
      .addCase(importZoomRecording.fulfilled, (state) => {
        state.importLoading = false;
      })
      .addCase(importZoomRecording.rejected, (state, action) => {
        state.importLoading = false;
        state.importError = action.payload;
      })
      
      // Google Drive Status
      .addCase(getGoogleDriveStatus.pending, (state) => {
        state.googleDriveLoading = true;
        state.googleDriveError = null;
      })
      .addCase(getGoogleDriveStatus.fulfilled, (state, action) => {
        state.googleDriveLoading = false;
        state.googleDriveStatus = action.payload;
      })
      .addCase(getGoogleDriveStatus.rejected, (state, action) => {
        state.googleDriveLoading = false;
        state.googleDriveError = action.payload;
      })
      
      // Authenticate Google Drive
      .addCase(authenticateGoogleDrive.pending, (state) => {
        state.googleDriveLoading = true;
        state.googleDriveError = null;
      })
      .addCase(authenticateGoogleDrive.fulfilled, (state, action) => {
        state.googleDriveLoading = false;
        state.googleDriveStatus = action.payload;
      })
      .addCase(authenticateGoogleDrive.rejected, (state, action) => {
        state.googleDriveLoading = false;
        state.googleDriveError = action.payload;
      })
      
      // Disconnect Google Drive
      .addCase(disconnectGoogleDrive.pending, (state) => {
        state.googleDriveLoading = true;
        state.googleDriveError = null;
      })
      .addCase(disconnectGoogleDrive.fulfilled, (state) => {
        state.googleDriveLoading = false;
        state.googleDriveStatus = null;
        state.googleDriveFiles = [];
      })
      .addCase(disconnectGoogleDrive.rejected, (state, action) => {
        state.googleDriveLoading = false;
        state.googleDriveError = action.payload;
      })
      
      // Get Google Drive Files
      .addCase(getGoogleDriveFiles.pending, (state) => {
        state.googleDriveLoading = true;
        state.googleDriveError = null;
      })
      .addCase(getGoogleDriveFiles.fulfilled, (state, action) => {
        state.googleDriveLoading = false;
        state.googleDriveFiles = action.payload;
      })
      .addCase(getGoogleDriveFiles.rejected, (state, action) => {
        state.googleDriveLoading = false;
        state.googleDriveError = action.payload;
      })
      
      // Search Google Drive Files
      .addCase(searchGoogleDriveFiles.pending, (state) => {
        state.googleDriveLoading = true;
        state.googleDriveError = null;
      })
      .addCase(searchGoogleDriveFiles.fulfilled, (state, action) => {
        state.googleDriveLoading = false;
        state.googleDriveFiles = action.payload;
      })
      .addCase(searchGoogleDriveFiles.rejected, (state, action) => {
        state.googleDriveLoading = false;
        state.googleDriveError = action.payload;
      })
      
      // Import Google Drive File
      .addCase(importGoogleDriveFile.pending, (state) => {
        state.importLoading = true;
        state.importError = null;
      })
      .addCase(importGoogleDriveFile.fulfilled, (state) => {
        state.importLoading = false;
      })
      .addCase(importGoogleDriveFile.rejected, (state, action) => {
        state.importLoading = false;
        state.importError = action.payload;
      });
  },
});

export const {
  resetZoomError,
  resetGoogleDriveError,
  resetImportError,
} = integrationsSlice.actions;

export default integrationsSlice.reducer;
