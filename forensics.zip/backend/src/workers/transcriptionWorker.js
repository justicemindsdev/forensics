require('dotenv').config();
const { consumeFromQueue } = require('../services/rabbitmq');
const TranscriptionService = require('../services/transcription');
const logger = require('../utils/logger');
const { setupDatabase } = require('../database');
const { setupRabbitMQ } = require('../services/rabbitmq');
const { setupRedis } = require('../services/redis');
const { setupMinIO } = require('../services/minio');

/**
 * Process a transcription job
 * @param {Object} jobData - Transcription job data
 */
async function processJob(jobData) {
  try {
    logger.info(`Received transcription job: ${jobData.id}`);
    
    // Process the transcription job
    await TranscriptionService.processTranscriptionJob(jobData);
    
    // Generate insights after transcription is complete
    if (jobData.options.generateInsights !== false) {
      try {
        // Get the transcript ID from the job data
        const transcriptId = `transcript_${jobData.recordingId}_${Date.now()}`;
        
        // Generate insights
        await TranscriptionService.generateInsights(transcriptId);
      } catch (insightError) {
        logger.error(`Error generating insights for job ${jobData.id}:`, insightError);
        // Don't fail the job if insights generation fails
      }
    }
    
    logger.info(`Completed transcription job: ${jobData.id}`);
  } catch (error) {
    logger.error(`Error processing transcription job ${jobData.id}:`, error);
    
    // Update job status to failed
    try {
      await TranscriptionService.updateJobStatus(jobData.id, 'failed', {
        error: error.message,
        errorStack: error.stack,
      });
    } catch (updateError) {
      logger.error(`Error updating job status for ${jobData.id}:`, updateError);
    }
  }
}

/**
 * Start the transcription worker
 */
async function startWorker() {
  try {
    logger.info('Starting transcription worker...');
    
    // Initialize services
    await setupDatabase();
    await setupRedis();
    await setupMinIO();
    await setupRabbitMQ();
    
    // Start consuming from the transcription queue
    await consumeFromQueue('transcription', processJob);
    
    logger.info('Transcription worker started successfully');
    
    // Keep the process running
    process.on('SIGINT', async () => {
      logger.info('Shutting down transcription worker...');
      process.exit(0);
    });
  } catch (error) {
    logger.error('Failed to start transcription worker:', error);
    process.exit(1);
  }
}

// Start the worker if this file is run directly
if (require.main === module) {
  startWorker();
}

module.exports = {
  startWorker,
  processJob,
};
