const { createClient } = require('redis');
const logger = require('../utils/logger');

let client = null;

/**
 * Initialize Redis connection
 */
const setupRedis = async () => {
  try {
    // Create Redis client
    client = createClient({
      url: process.env.REDIS_URL
    });
    
    // Handle errors
    client.on('error', (err) => {
      logger.error('Redis client error:', err);
    });
    
    // Handle connection
    client.on('connect', () => {
      logger.info('Connected to Redis');
    });
    
    // Handle reconnection
    client.on('reconnecting', () => {
      logger.info('Reconnecting to Redis');
    });
    
    // Handle end
    client.on('end', () => {
      logger.info('Redis connection ended');
    });
    
    // Connect to Redis
    await client.connect();
    
    return client;
  } catch (error) {
    logger.error('Failed to connect to Redis:', error);
    throw error;
  }
};

/**
 * Set a value in Redis
 * @param {string} key - Key to set
 * @param {string|object} value - Value to set
 * @param {number} expiry - Expiry time in seconds (optional)
 */
const setCache = async (key, value, expiry = null) => {
  try {
    if (!client) {
      throw new Error('Redis client not initialized');
    }
    
    // Convert object to string if necessary
    const valueToStore = typeof value === 'object' ? JSON.stringify(value) : value;
    
    // Set value with expiry if provided
    if (expiry) {
      await client.set(key, valueToStore, { EX: expiry });
    } else {
      await client.set(key, valueToStore);
    }
    
    logger.debug(`Cache set for key: ${key}`);
    return true;
  } catch (error) {
    logger.error(`Failed to set cache for key ${key}:`, error);
    throw error;
  }
};

/**
 * Get a value from Redis
 * @param {string} key - Key to get
 * @param {boolean} parseJson - Whether to parse the value as JSON
 */
const getCache = async (key, parseJson = true) => {
  try {
    if (!client) {
      throw new Error('Redis client not initialized');
    }
    
    const value = await client.get(key);
    
    if (!value) {
      return null;
    }
    
    // Parse JSON if requested
    if (parseJson) {
      try {
        return JSON.parse(value);
      } catch (e) {
        // If not valid JSON, return as is
        return value;
      }
    }
    
    return value;
  } catch (error) {
    logger.error(`Failed to get cache for key ${key}:`, error);
    throw error;
  }
};

/**
 * Delete a value from Redis
 * @param {string} key - Key to delete
 */
const deleteCache = async (key) => {
  try {
    if (!client) {
      throw new Error('Redis client not initialized');
    }
    
    await client.del(key);
    logger.debug(`Cache deleted for key: ${key}`);
    return true;
  } catch (error) {
    logger.error(`Failed to delete cache for key ${key}:`, error);
    throw error;
  }
};

/**
 * Close Redis connection
 */
const closeRedis = async () => {
  try {
    if (client) {
      await client.quit();
      logger.info('Redis connection closed');
    }
  } catch (error) {
    logger.error('Error closing Redis connection:', error);
    throw error;
  }
};

module.exports = {
  setupRedis,
  setCache,
  getCache,
  deleteCache,
  closeRedis
};
