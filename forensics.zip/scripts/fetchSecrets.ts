import { SecretsManagerClient, GetSecretValueCommand } from "@aws-sdk/client-secrets-manager";
import * as dotenv from "dotenv";
import * as fs from "fs";
import * as path from "path";

// Load any existing .env file as fallback for local development
dotenv.config();

/**
 * Fetch secrets from AWS Secrets Manager and write them to .env file
 * @param {string} secretName - The name of the secret in AWS Secrets Manager
 * @param {string} region - AWS region
 * @param {boolean} writeToFile - Whether to write secrets to .env file (default: true)
 * @returns {Promise<Record<string, string>>} - Object containing the secrets
 */
export async function fetchSecrets(
  secretName: string = process.env.AWS_SECRET_NAME || "justice-minds/dev",
  region: string = process.env.AWS_REGION || "us-east-1",
  writeToFile: boolean = true
): Promise<Record<string, string>> {
  try {
    console.log(`Fetching secrets from ${secretName} in ${region}...`);
    
    // Create AWS Secrets Manager client
    const client = new SecretsManagerClient({ region });
    
    // Create command to get secret value
    const command = new GetSecretValueCommand({ SecretId: secretName });
    
    // Send command to AWS Secrets Manager
    const response = await client.send(command);
    
    if (!response.SecretString) {
      throw new Error("Secret string is empty");
    }
    
    // Parse secret string to JSON
    const secrets = JSON.parse(response.SecretString) as Record<string, string>;
    
    // Write secrets to .env file if requested
    if (writeToFile) {
      const envPath = path.resolve(process.cwd(), ".env");
      let envContent = "";
      
      // Format secrets as KEY=VALUE pairs
      for (const [key, value] of Object.entries(secrets)) {
        envContent += `${key}=${value}\n`;
      }
      
      // Write to .env file
      fs.writeFileSync(envPath, envContent);
      console.log(`✅ Secrets written to ${envPath}`);
    }
    
    // Return secrets object
    return secrets;
  } catch (error) {
    console.error("❌ Error fetching secrets:", error);
    throw error;
  }
}

/**
 * Inject secrets into process.env
 * @param {Record<string, string>} secrets - Object containing secrets
 */
export function injectSecrets(secrets: Record<string, string>): void {
  for (const [key, value] of Object.entries(secrets)) {
    process.env[key] = value;
  }
  console.log("✅ Secrets injected into process.env");
}

// Run script if called directly
if (require.main === module) {
  (async () => {
    try {
      // Get command line arguments
      const args = process.argv.slice(2);
      const secretName = args[0] || process.env.AWS_SECRET_NAME || "justice-minds/dev";
      const region = args[1] || process.env.AWS_REGION || "us-east-1";
      const writeToFile = args[2] !== "false";
      
      // Fetch secrets
      const secrets = await fetchSecrets(secretName, region, writeToFile);
      
      // Inject secrets into process.env
      injectSecrets(secrets);
      
      console.log("✅ Secrets fetched successfully");
    } catch (error) {
      console.error("❌ Failed to fetch secrets:", error);
      process.exit(1);
    }
  })();
}
