import { NextApiRequest, NextApiResponse } from 'next';
import { 
  fetchFromSource, 
  fetchFromAllSources, 
  sourceExists, 
  getSourceUrl 
} from '../../../apigrain/apiGrainUtils';
import * as grainApi from '../../../apigrain/grainApiClient';

/**
 * API route to fetch data from API Grain sources
 * 
 * GET /api/apigrain/all - Fetch data from all sources
 * GET /api/apigrain/[source] - Fetch data from a specific source
 */
export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  // Only allow GET requests
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { source } = req.query;
    
    // Handle request for all sources
    if (source === 'all') {
      const data = await fetchFromAllSources();
      return res.status(200).json(data);
    }
    
    // Handle request for a specific source
    if (typeof source === 'string') {
      // Special handling for Grain API endpoints
      if (source === 'grain.com') {
        return handleGrainApiRequest(req, res);
      }
      
      // Check if the source exists
      if (!sourceExists(source)) {
        return res.status(404).json({ 
          error: `Source '${source}' not found`,
          availableSources: Object.keys(await fetchFromAllSources())
        });
      }
      
      // Get the URL for the source
      const url = getSourceUrl(source);
      
      // Fetch data from the source
      const data = await fetchFromSource(source);
      
      return res.status(200).json({
        source,
        url,
        data
      });
    }
    
    // Invalid request
    return res.status(400).json({ error: 'Invalid request' });
  } catch (error) {
    console.error('Error in API Grain API route:', error);
    return res.status(500).json({ 
      error: 'Internal server error', 
      message: (error as Error).message 
    });
  }
}

/**
 * Handle requests to the Grain API
 */
async function handleGrainApiRequest(req: NextApiRequest, res: NextApiResponse) {
  try {
    const { endpoint, recordingId, ...options } = req.query;
    
    // Handle different Grain API endpoints
    if (endpoint === 'me') {
      const data = await grainApi.getCurrentUser();
      return res.status(200).json(data);
    } 
    
    if (endpoint === 'views') {
      const data = await grainApi.getViews(options);
      return res.status(200).json(data);
    }
    
    if (endpoint === 'hooks') {
      const data = await grainApi.getHooks();
      return res.status(200).json(data);
    }
    
    if (recordingId && typeof recordingId === 'string') {
      const data = await grainApi.getRecording(recordingId, options);
      return res.status(200).json(data);
    }
    
    // Default to fetching recordings
    const data = await grainApi.getRecordings(options);
    return res.status(200).json(data);
  } catch (error) {
    console.error('Error handling Grain API request:', error);
    return res.status(500).json({ 
      error: 'Error handling Grain API request', 
      message: (error as Error).message 
    });
  }
}
